package ch.mysign.test;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.security.AccessSecurityException;
import org.apache.sling.resourceaccesssecurity.AllowingResourceAccessGate;
import org.apache.sling.resourceaccesssecurity.ResourceAccessGate;
import org.osgi.framework.Constants;

@Component(
        name = "ch.mysign.test.LockDownGate",
        immediate = true )
@Service( value={ResourceAccessGate.class})
   @Properties({
       @Property(name = Constants.SERVICE_DESCRIPTION, value = "Test for Lockdown via ResourceAccessGate"),
       @Property(name = Constants.SERVICE_VENDOR, value = "MySign"),
       
       @Property(name = ResourceAccessGate.CONTEXT, value = ResourceAccessGate.APPLICATION_CONTEXT),
       @Property(name = ResourceAccessGate.PATH, value = ".*"),
       @Property(name = ResourceAccessGate.FINALOPERATIONS, value = "read,create,update,delete"),
       @Property(name = Constants.SERVICE_RANKING, intValue = 1000, propertyPrivate = false )
   })
public class LockDownGate extends AllowingResourceAccessGate implements ResourceAccessGate {

    @Override
    public boolean hasReadRestrictions(ResourceResolver resourceResolver) {
        //return !isLoggedIn( resourceResolver.getUserID() );
        return true;
     }

    @Override
    public boolean hasCreateRestrictions(ResourceResolver resourceResolver) {
        //return !isLoggedIn( resourceResolver.getUserID() );
        return true;
    }

    @Override
    public boolean hasUpdateRestrictions(ResourceResolver resourceResolver) {
        //return !isLoggedIn( resourceResolver.getUserID() );
        return true;
    }

    @Override
    public boolean hasDeleteRestrictions(ResourceResolver resourceResolver) {
        //return !isLoggedIn( resourceResolver.getUserID() );
        return true;
    }

    private boolean isLoggedIn ( String user ) {
        return ( user != null  && !user.equals("anonymous") );
    }


 
    
    
    
    @Override
    public GateResult canRead(Resource resource) {
        return checkAccess( resource.getResourceResolver() );
    }

    @Override
    public GateResult canCreate(String absPathName, ResourceResolver resourceResolver) {
        return checkAccess( resourceResolver );
    }

    @Override
    public GateResult canUpdate(Resource resource) {
        return checkAccess( resource.getResourceResolver() );
    }

    @Override
    public GateResult canDelete(Resource resource) {
        return checkAccess( resource.getResourceResolver() );
    }

    private GateResult checkAccess ( ResourceResolver resourceResolver ) {
        if ( isLoggedIn( resourceResolver.getUserID() ) )
        {
            return GateResult.CANT_DECIDE;
        }
        else
        {
            return GateResult.DENIED;
        }
    }
    
    
}
