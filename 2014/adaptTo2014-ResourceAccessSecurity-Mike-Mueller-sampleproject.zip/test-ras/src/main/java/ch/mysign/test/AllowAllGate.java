package ch.mysign.test;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.security.AccessSecurityException;
import org.apache.sling.resourceaccesssecurity.AllowingResourceAccessGate;
import org.apache.sling.resourceaccesssecurity.ResourceAccessGate;
import org.apache.sling.resourceaccesssecurity.ResourceAccessGate.GateResult;
import org.osgi.framework.Constants;

@Component(
        name = "ch.mysign.test.AllowAllGate",
        immediate = true )
@Service( value={ResourceAccessGate.class})
   @Properties({
       @Property(name = Constants.SERVICE_DESCRIPTION, value = "Allow all"),
       @Property(name = Constants.SERVICE_VENDOR, value = "MySign"),
       @Property(name = ResourceAccessGate.CONTEXT, value = ResourceAccessGate.APPLICATION_CONTEXT),
       @Property(name = ResourceAccessGate.PATH, value = "(?!/mongo/).*"),
       @Property(name = ResourceAccessGate.OPERATIONS, value = "read,create,update,delete")
   })
public class AllowAllGate extends AllowingResourceAccessGate {

}
