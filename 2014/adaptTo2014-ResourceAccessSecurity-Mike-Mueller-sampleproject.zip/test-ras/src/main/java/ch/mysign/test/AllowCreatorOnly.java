package ch.mysign.test;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.security.AccessSecurityException;
import org.apache.sling.resourceaccesssecurity.AllowingResourceAccessGate;
import org.apache.sling.resourceaccesssecurity.ResourceAccessGate;
import org.apache.sling.resourceaccesssecurity.ResourceAccessGate.GateResult;
import org.osgi.framework.Constants;

@Component(
        name = "ch.mysign.test.AllowCreatorOnly",
        immediate = true )
@Service( value={ResourceAccessGate.class})
   @Properties({
       @Property(name = Constants.SERVICE_DESCRIPTION, value = "Allow creator1 resources only"),
       @Property(name = Constants.SERVICE_VENDOR, value = "MySign"),
       
       @Property(name = ResourceAccessGate.CONTEXT, value = ResourceAccessGate.APPLICATION_CONTEXT),
       @Property(name = ResourceAccessGate.PATH, value = "/mongo/.*"),
       @Property(name = ResourceAccessGate.OPERATIONS, value = "read,create,update,delete")
   })

public class AllowCreatorOnly extends AllowingResourceAccessGate {
    
    private static final String ALLOWED_USER = "user000001";
    
    @Override
    public boolean hasReadRestrictions(ResourceResolver resourceResolver) {
        return true;
     }

    @Override
    public boolean hasCreateRestrictions(ResourceResolver resourceResolver) {
        return true;
    }

    @Override
    public boolean hasUpdateRestrictions(ResourceResolver resourceResolver) {
        return true;
    }

    @Override
    public boolean hasDeleteRestrictions(ResourceResolver resourceResolver) {
        return true;
    }

    @Override
    public GateResult canRead(Resource resource) {
        return checkAccess(resource);
    }

    @Override
    public GateResult canCreate(String absPathName, ResourceResolver resourceResolver) {
        return GateResult.GRANTED;
    }

    @Override
    public GateResult canUpdate(Resource resource) {
        return checkAccess(resource);
    }

    @Override
    public GateResult canDelete(Resource resource) {
        return checkAccess(resource);
    }

    private GateResult checkAccess(Resource resource) {
        if ( isCreator1( resource ) )
        {
            return GateResult.GRANTED;
        }
        else
        {
            return GateResult.DENIED;
        }
    }

    private boolean isCreator1 ( Resource resource )
    {
        boolean returnValue = false;
        
        ValueMap values = resource.getValueMap();
        String user = resource.getResourceResolver().getUserID();
        if ( values != null && user != null  && !user.equals("anonymous") )
        {
            Object creator = values.get("creator");
            returnValue = creator != null ? creator.toString().equals( ALLOWED_USER ) : false;
        }
        
        return returnValue;
    }
    
    
    
    
    
    
    @Override
    public String transformQuery(final String query, final String language,
            final ResourceResolver resourceResolver) throws AccessSecurityException {
        String returnValue = query;
        
        if ( language.equals("mongodb") && query.indexOf("{") > 0 )
        {
            {
                returnValue = query.substring(0, query.indexOf("{") + 1 ) + "creator:\"" + ALLOWED_USER + "\"," + query.substring(query.indexOf("{") + 1);
            }
        }
        return returnValue;
    }

    
}
