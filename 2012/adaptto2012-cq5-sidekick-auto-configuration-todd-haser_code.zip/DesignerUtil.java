package com.yourproject.utils;

import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.api.PageManager;
import com.day.cq.wcm.api.WCMException;
import com.day.cq.wcm.api.designer.Design;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.lang.WordUtils;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Created by IntelliJ IDEA.
 * User: Todd J. Haser
 * Date: 26/9/2012
 * Time: 12:30 PM
 *
 * This Class is used to auto-create and configure design templates for various landing pages
 */
public class DesignerUtil {
    private static final Logger log = LoggerFactory.getLogger(DesignerUtil.class);

    public static final String YOUR_LANDING_LANDING_PAGE = "yourlandingpage";
    private static final String DEFAULT_DESIGN_PATH = "/etc/designs/yourprojectname";
    private static final String DESIGN_TEMPLATE = "/libs/wcm/core/templates/designpage";
    private static final String SOME_COMPONENT1 = "/apps/yourproject/components/somecomponent1";
    private static final String SOME_COMPONENT2 = "/apps/yourproject/components/somecomponent2";

    /**
     * Main entry point for your landing page
     * This method checks to see if a matching design already exists for the your landing page
     * If it does, it bails out
     * If it does not, then it does the following items:
     * - Creates a design template with a matching taxonomy (/content/ taxonomy is used to create /etc/design taxonomy)
     * - Creates, configures, and adds template entries for landing page
     * - Adds designTemplate path to the design template path variable of the page properties (for end-user's verification)
     *
     * @param currentPage
     * @param pageManager
     * @param adminSession
     * @return
     */
    public static String ConfigureDesignTemplate(Page currentPage, PageManager pageManager, Session adminSession) {
        String result = "Does not exist";

        // get the current page's template type (name)...
        String templateName = JcrHelper.getTemplateName(currentPage);
        log.debug("---templateName: " + templateName);

        if( templateName.equals(CULDESAC_LANDING_PAGE)) {
        	String pagePath = currentPage.getPath();
        	String pageName = currentPage.getName();
        	String pageTitle = currentPage.getTitle();

        	int start = new String("/content/yourapp").length();
            int end = pagePath.length();
            String concatPath = pagePath.substring( start, end );
            concatPath = concatPath.substring(0, concatPath.lastIndexOf("/") );
            String designPath = DEFAULT_DESIGN_PATH + concatPath;

            // Does this path + page exist?
            Page designTemplate = pageManager.getPage(designPath + "/" + pageName);
            if( designTemplate == null ) {
            	// validate that the design path exists (or create it)
            	validateDesignPath(pageManager, designPath);
            	// create the design template/page
            	try {
            		designTemplate = createDesignPage(pageManager, designPath, pageName, pageTitle);
            		Node currentPageNode = currentPage.adaptTo(javax.jcr.Node.class);
            		Node currentPageJcrNode = currentPageNode.getNode("jcr:content");
            		currentPageJcrNode.setProperty("cq:designPath", designTemplate.getPath() );
            		currentPageJcrNode.save();

            		// Assign culdesaclandingpage and culdesaclevel2 nodes and pre-set the defaults...
            		Node designNode = designTemplate.adaptTo(javax.jcr.Node.class);
            		Node designJcrNode = designNode.getNode("jcr:content");
            		configYourLandingPageDesign(currentPage, designJcrNode );
            	} catch (Exception e) {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    log.error( sw.toString() );
                    result = "error - check log files...";
                }

            }

            log.debug("designTemplate name: " + designTemplate.getName() );

            result = "design template successfully created";
        } else {
        	result = "design template already exists";
        }


        log.debug( "result: " + result );
        return result;
    }


    /**
     * This method iterates over a design path (like /etc/designs/yourapp/global/en/blah1/blah2) to
     * determine that each section of the path exists as a design template.  If it doesn't, it iteratively
     * creates the necessary design templates...
     *
     * @param pageManager
     * @param designPath
     */
    private static void validateDesignPath( PageManager pageManager, String designPath ) {
        String[] tokenizedPath;
        tokenizedPath = designPath.split("/");

        String tempPath = DEFAULT_DESIGN_PATH;
        for( int i = 4; i < tokenizedPath.length; i++ ) {
        	String previousPath = tempPath;
        	tempPath += "/" + tokenizedPath[i];
        	// Does this path + page exist?
            Page page = pageManager.getPage(tempPath);
            if( page == null ) {
            	try {
					createDesignPage(pageManager, previousPath, tokenizedPath[i], tokenizedPath[i]);
				} catch (Exception e) {
					StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    log.error( sw.toString() );
				}
            }
        }
    }

    /**
     * This method creates a Design Template/Page at a given path
     *
     * @param pageManager
     * @param parentPath
     * @param pageName
     * @param title
     * @return
     * @throws RepositoryException
     * @throws WCMException
     */
    private static Page createDesignPage(PageManager pageManager, String parentPath, String pageName, String title )
            throws RepositoryException, WCMException {
        Page designPage = pageManager.create( parentPath, pageName, DESIGN_TEMPLATE, title );

        // set some properties.
        if( designPage != null ) {
            Node designNode = designPage.adaptTo(javax.jcr.Node.class);
            Node designJcrNode = designNode.getNode("jcr:content");
            designJcrNode.setProperty("cq:template", "/libs/wcm/core/templates/designpage");
            designJcrNode.setProperty("sling:resourceType", "wcm/core/components/designer");
            designJcrNode.save();
        }

        return designPage;
    }


    /**
     * Populate the Sidekick AND add default settings for component design properties
     *
     * @param currentPage
     * @param designNode
     * @throws Exception
     */
    private static void configYourLandingPageDesign( Page currentPage, Node designNode )
            throws Exception {
        // Create all of the various template nodes, children nodes, and respective properties and append to the
        // designNode...

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // YOURLANDINGPAGE                                                                                            //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Node landingPageNode = designNode.addNode("./culdesaclandingpage", "nt:unstructured");

        // Create and populate your parsys
        Node partop = landingPageNode.addNode("./your-main-parsys", "nt:unstructured");
        partop.setProperty("components", new String[] {
                SOMECOMPONENT1,
                SOMECOMPONENT2
                // more components...
        });
        partop.setProperty("sling:resourceType", "foundation/components/parsys");
        partop.addNode("./section", "nt:unstructured");

        // Create and populate any additional parsys
        //....
        
        // Populate design component properties (like main nav, for example)
        // add the main nav
        setMainNav( currentPage, landingPageNode );

		//...

        // save all the work
        designNode.save();

    }

    /**
     * This method is used to set the main nav design properties...
     *
     * @param currentPage
     * @param templateTypeNode
     * @throws Exception
     */
    private static void setMainNav( Page currentPage,  Node templateTypeNode )
        throws Exception {
        // get the path to the currentPage
        String crumbAndNavPath = currentPage.getPath();

        Node mainNav = templateTypeNode.addNode("./your-main-nav-component", "nt:unstructured");
        mainNav.setProperty("mainnavparentpage", crumbAndNavPath);
        mainNav.setProperty("sling:resourceType", "yourapp/components/your-main-nav-component");
    }


}
