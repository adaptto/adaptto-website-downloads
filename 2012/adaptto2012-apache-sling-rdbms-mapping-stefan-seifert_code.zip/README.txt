adapTo() 2012 - Sling & RDBMS Sample Code
=========================================

DISCLAIMER: This source code provided is a technological prototype.
It is neither feature complete nor production-ready. If you see a bunch of strange
warnings and errors in the sling or CQ5 stacktraces, please do not contact the authors.
This code evaluates technical principles and works only for the sampls provided in
the adaptTo() 2012 presentation. Have fun anyway.


Prerequisite
============

- MySQL 5.x database
- Maven 3
- Apache Sling trunk Rev. 1391097
- Optionally: CQ 5.5


Prepare database
==============

1. Setup a mySQL 5.x database

2. Create a new database
- create database birt default character set utf8;

3. Create database schema
- Run script birt-database-2_0_1/ClassicModels/ClassicModels/mysql/create_classicmodels.sql
- If you're running it the first time you have to remove the DROP TABLE * statements at
  the beginning of the file

4. Populate database
- Run script birt-database-2_0_1/ClassicModels/ClassicModels/mysql/load_classicmodels.sql
- You may have to adapt the path to the datafiles directory


Installation on Sling
=====================

0. Start Sling trunk Rev. 1391097

1. Compile all
- Go to root of sample code and execute
  mvn clean install

2. Deploy 3rdparty bundles
- Go to 3rdparty-bundles-sling/target
- Unzip org.adaptto.slingrdbms.3rdparty-bundles-sling-*.zip
- From the containing folder jcr_root/apps/slingrdbms-3rparty/install
  upload and install all bundles via Felix OSGi console

3. Remove JRE Java Transaction API
- In Felix OSGi console remove the fragment bundle 
  "Apache Sling System Bundle Extension: Java Transaction API"

4. Restart Sling

5. Deploy sample application
- Go to root of sample code and execute
  mvn -Psling-install install

6. Check bundle state
- Go to Felix OSGi console and check if all bundles are in "active" state (or "fragment")
- If not try to restart Sling, and try to start bundles manually

7. Check configuration
- Configuration should be deployed automatically with the bundles
- Re-check configuration for
  "JDBC Connections Pool"
  "adaptto Sling&RDBMS Resource Provicer Factory"

8. Test
- Open http://localhost:8080/content/table/product.html

- If it does not work at all try to re-save the configuration entries mentioned above
- This will restart the associated services which may help


Installation on CQ5
===================

DISCLAIMER: Deploying the sample code to CQ5 will break you CQ5 instance!
Some features (default page .html view, page properties) will not work any more.
Reason is the partially update to sling trunk to get this demo running.
In CQ56 you can remove the sling trunk bundles and all should work well (not testet yet).
Conclusion: This is only for the brave ones.

0. Start CQ5.5

1. Compile all
- Go to root of sample code and execute
  mvn clean install

2. Deploy 3rdparty bundles and sample application
- Go to root of sample code and execute
  mvn -Pcq5-install install

3. Check bundle state
- Go to Felix OSGi console and check if all bundles are in "active" state (or "fragment")
- If not try to restart CQ5, and try to start bundles manually

4. Check configuration
- Configuration should be deployed automatically with the bundles
- Re-check configuration for
  "JDBC Connections Pool"
  "adaptto Sling&RDBMS Resource Provicer Factory"

5. Test
- Open http://localhost:4502/content/table/product.overview.html

- If it does not work at all try to re-save the configuration entries mentioned above
- This will restart the associated services which may help


(c) 2012 pro!vision GmbH, Stefan Seifert
http://www.pro-vision.de/

Contains code parts from everit.org http://everit.org/osgi/index.html (Hibernate Adapter)
And a BIRT sample database from the Eclipse BIRT project.
