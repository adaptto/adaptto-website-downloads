/*
 * Copyright 1997-2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */

/**
 * @class slingrdbms.cq5editor.widgets.data.SlingReader
 * @extends CQ.Ext.data.JsonReader
 * Data reader class to create an Array of {@link slingrdbms.cq5editor.widgets.data.SlingRecord SlingRecord} objects
 * from a Sling JSON response.<br>
 * SlingReaders are usualy build solely from a {@link slingrdbms.cq5editor.widgets.data.SlingStore SlingStore.}<br><br>
 * <b>NOTE: Although they are listed this class does not support some of the config options
 * inherited of {@link CQ.Ext.data.JsonReader}.</b>{@link #root}, {@link #successProperty} and
 * {@link #totalProperty} are set internally.
 * @constructor
 * Create a new SlingReader
 */
slingrdbms.cq5editor.widgets.data.SlingReader = function() {
  slingrdbms.cq5editor.widgets.data.SlingReader.superclass.constructor.call(this, {});
};
CQ.Ext.extend(slingrdbms.cq5editor.widgets.data.SlingReader, CQ.Ext.data.JsonReader, {

  /**
   * This method is only used by a DataProxy which has retrieved data from a remote server.
   * @param {Object} response The XHR object which contains the Sling formatted JSON data
   * in its responseText.
   * @return {Object} data A data block which is used by a CQ.Ext.data.SlingStore
   * as a cache of CQ.Ext.data.SlingRecords.
   */
  read : function(response) {
    var json = response.responseText;
    var rootData = eval("(" + json + ")");
    if (!rootData) {
      throw {
        message : "SlingReader.read: Json object not found"
      };
    }

    var fields = null;
    var data = [];
    for (var itemName in rootData) {
      var item = rootData[itemName];
      if (!(item instanceof Object)) {
        continue;
      }
      
      // get fields structure from first record
      if (!fields) {
        fields = [];
        for (var propName in item) {
          //todo: type?
          var mappedName = propName.replace(/\./g, "%2e");
          if (mappedName != propName) {
            fields.push({
              name : propName,
              mapping : mappedName
            });
          }
          else {
            fields.push(propName);
          }
        }
      }
      
      var record = {};
      for (var propName in item) {
        //todo: type?
        var mappedName = propName.replace(/\./g, "%2e");
        record[mappedName] = item[propName];
      }
      data.push(record);
      
    }

    var o = {
      "root" : data,
      "results" : data.length,
      "success" : true,
      "metaData" : {
        "successProperty" : "success",
        "totalProperty" : "results",
        "root" : "root",
        "idProperty": rootData.idColumn,
        "fields" : fields
      }
    };

    delete this.ef;
    this.meta = o.metaData;
    this.onMetaChange(this.meta, this.recordType, o);
    // bug #28019: this.recordType is set by this.onMetaChange in Ext 3.1.1 (was
    // set by readRecords in 2.x.x; onMetaChange was an empty function there)
    this.recordType = CQ.data.SlingRecord.create(o.metaData.fields);

    // remove metadata so that sling records are created (bug #28019: this is still
    // required, as readRecord calls this.onMetaChange)
    delete o.metaData;
    return this.readRecords(o);
  }

});
