/*
 * Copyright 1997-2008 Day Management AG
 * Barfuesserplatz 6, 4001 Basel, Switzerland
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Day Management AG, ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Day.
 */

/**
 * @class slingrdbms.cq5editor.widgets.data.SlingStore
 * @extends CQ.Ext.data.Store
 * Small helper class to make creating Stores for remotely-loaded JSON data provided by Sling easier.
 * SlingStore is pre-configured with a built-in {@link CQ.Ext.data.HttpProxy HttpProxy} and a
 * {@link slingrdbms.cq5editor.widgets.data.SlingReader SlingReader}.<br/>
<pre><code>
var store = new slingrdbms.cq5editor.widgets.data.SlingStore({
    url: 'foo/bar.json'
});
</code></pre>
 * This would consume a response of the form:
<pre><code>
{
    "title": "The Title",
    "text": "The text."
}
</code></pre>
 * @constructor
 * @param {Object} config
 * @cfg {String} url  The URL from which to load data through an HttpProxy.
 */
slingrdbms.cq5editor.widgets.data.SlingStore = function(c) {
  slingrdbms.cq5editor.widgets.data.SlingStore.superclass.constructor.call(this, CQ.Ext.apply(c, {
    proxy: !c.data ? new CQ.Ext.data.HttpProxy({url: c.url}) : undefined,
    reader: new slingrdbms.cq5editor.widgets.data.SlingReader(c)
  }));
};

CQ.Ext.extend(slingrdbms.cq5editor.widgets.data.SlingStore, CQ.Ext.data.Store);
