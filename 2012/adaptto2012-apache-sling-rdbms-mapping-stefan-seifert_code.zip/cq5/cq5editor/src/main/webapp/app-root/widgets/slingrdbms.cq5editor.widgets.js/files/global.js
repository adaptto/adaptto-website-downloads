/**
 * Namespace definitions
 */
CQ.Ext.namespace("slingrdbms.cq5editor.widgets");
CQ.Ext.namespace("slingrdbms.cq5editor.widgets.data");
