/**
 * Table editor grid
 */
slingrdbms.cq5editor.widgets.TableEditorPanel = CQ.Ext.extend(CQ.Ext.grid.EditorGridPanel, {
  
  gridStore: null,
  
  /**
   * Creates a new component.
   * @param config configuration
   */
  constructor: function(config) {
    config = config || {};

    // prepare data store for table with sub elements
    this.gridStore = new slingrdbms.cq5editor.widgets.data.SlingStore({
      url: CQ.HTTP.noCaching(CQ.Util.externalize("/content/table/product.infinity" + CQ.HTTP.EXTENSION_JSON)),
      autoSave: false/*,
      writer: new CQ.Ext.data.JsonWriter({
        
      })*/
    });
    this.gridStore.load();
    
    var defaults = {
      viewConfig: {
        forceFit: true
      },
      colModel: new CQ.Ext.grid.ColumnModel([
        {
          id: "productName",
          header: "Product name",
          dataIndex: "productName",
          editor: new CQ.Ext.form.TextField()
        },
        {
          id: "productVendor",
          header: "Product vendor",
          dataIndex: "productVendor",
          editor: new CQ.Ext.form.TextField()
        },
        {
          id: "productDescription",
          header: "Product description",
          dataIndex: "productDescription",
          editor: new CQ.Ext.form.TextField()
        },
        {
          id: "buyPrice",
          header: "Buy price",
          dataIndex: "buyPrice",
          editor: new CQ.Ext.form.TextField()
        },
        {
          id: "quantityInStock",
          header: "Quantity in Stock",
          dataIndex: "quantityInStock",
          editor: new CQ.Ext.form.TextField()
        }
      ]),
      store: this.gridStore
    };
    CQ.Util.applyDefaults(config, defaults);
    slingrdbms.cq5editor.widgets.TableEditorPanel.superclass.constructor.call(this, config);
  }
  
});

CQ.Ext.reg("slingrdbms.cq5editor.tableeditorpanel", slingrdbms.cq5editor.widgets.TableEditorPanel);
