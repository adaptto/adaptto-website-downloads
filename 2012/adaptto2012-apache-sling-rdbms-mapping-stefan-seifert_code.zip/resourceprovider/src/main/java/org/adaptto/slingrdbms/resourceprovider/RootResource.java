package org.adaptto.slingrdbms.resourceprovider;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;

import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;

/**
 * Root resource which maps to a table in RDBMS
 */
class RootResource extends AbstractRdbmsResource {

  private final Class mEntityClass;
  private final List<FieldMapper> mFieldMappers;
  private String mResourceTypePrefix;

  /**
   * @param pPath Resource path
   * @param pResourceResolver Resource resolver
   * @param pEntityClass Entity class
   * @param pFieldMappers Field mappers
   * @param pResourceTypePrefix Resource type prefix
   */
  public RootResource(String pPath, ResourceResolver pResourceResolver, Class pEntityClass,
      List<FieldMapper> pFieldMappers, String pResourceTypePrefix) {
    super(pPath, createValueMap(), createResourceType(pEntityClass, pResourceTypePrefix), pResourceResolver);

    mEntityClass = pEntityClass;
    mFieldMappers = pFieldMappers;
    mResourceTypePrefix = pResourceTypePrefix;

    ValueMap props = this.adaptTo(ValueMap.class);

    // show table name in root entity
    props.put("table", EntityUtil.getTableName(pEntityClass));

    // show id column name
    for (FieldMapper fieldMapper : pFieldMappers) {
      if (fieldMapper.isIsId()) {
        props.put("idColumn", fieldMapper.getName());
        break;
      }
    }

    // put resource type to value map as well
    this.adaptTo(ValueMap.class).put(SlingConstants.NAMESPACE_PREFIX + ":" + SlingConstants.PROPERTY_RESOURCE_TYPE, getResourceType());
  }

  private static ValueMap createValueMap() {
    return new ValueMapDecorator(new HashMap<String,Object>());
  }

  private static String createResourceType(Class pEntityClass, String pResourceTypePrefix) {
    return pResourceTypePrefix + "/" + EntityUtil.getTableName(pEntityClass);
  }

  /**
   * List rows in table as child resources
   * @param pEntityManager Entity manager
   * @return Child resources
   */
  public Iterator<Resource> listChildren(EntityManager pEntityManager) {
    List results = pEntityManager.createQuery("SELECT e FROM " + mEntityClass.getSimpleName() + " e").getResultList();
    return new RowResourceIterator(results.iterator(), mFieldMappers, mResourceTypePrefix, getPath(), getResourceResolver());
  }

  /**
   * Iterates over JPA result set and creates resource instance for each row.
   */
  public static class RowResourceIterator implements Iterator<Resource> {

    private final Iterator mRowIterator;
    private final List<FieldMapper> mFieldMappers;
    private final String mResourceTypePrefix;
    private final String mParentPath;
    private final ResourceResolver mResourceResolver;

    /**
     * @param pRowIterator Resultset iterator
     * @param pFieldMappers Field mappers
     * @param pResourceTypePrefix Resource type prefix
     * @param pParentPath Parent path
     * @param pResourceResolver Resource resolver
     */
    public RowResourceIterator(Iterator pRowIterator, List<FieldMapper> pFieldMappers,
        String pResourceTypePrefix, String pParentPath, ResourceResolver pResourceResolver) {
      mRowIterator = pRowIterator;
      mFieldMappers = pFieldMappers;
      mResourceTypePrefix = pResourceTypePrefix;
      mParentPath = pParentPath;
      mResourceResolver = pResourceResolver;
    }

    @Override
    public boolean hasNext() {
      return mRowIterator.hasNext();
    }

    @Override
    public Resource next() {
      Object entity = mRowIterator.next();
      return new EntityResource(mResourceResolver, entity, mFieldMappers, mResourceTypePrefix, mParentPath);
    }

    @Override
    public void remove() {
      throw new UnsupportedOperationException();
    }

  }


}
