package org.adaptto.slingrdbms.resourceprovider;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;

import org.adaptto.slingrdbms.valuemap.EntityPropertyValueMap;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

/**
 * Resource which maps to a single entity/row in a RDBMS table
 */
class EntityResource extends AbstractRdbmsResource {

  @SuppressWarnings("unused")
  private final Object mEntity;
  @SuppressWarnings("unused")
  private final List<FieldMapper> mFieldMappers;

  /**
   * @param pResourceResolver Resource resolver
   * @param pEntity Entity instance
   * @param pFieldMappers Field mappers
   * @param pResourceTypePrefix Resource type prefix
   * @param pParentPath Parent path
   */
  public EntityResource(ResourceResolver pResourceResolver, Object pEntity,
      List<FieldMapper> pFieldMappers, String pResourceTypePrefix, String pParentPath) {
    super(buildPathFromIds(pParentPath, pEntity, pFieldMappers),
        createValueMap(pEntity, pFieldMappers, createResourceType(pEntity.getClass(), pResourceTypePrefix)),
        createResourceType(pEntity.getClass(), pResourceTypePrefix), pResourceResolver);
    mEntity = pEntity;
    mFieldMappers = pFieldMappers;
  }

  /**
   * @param pResourceResolver Resource resolver
   * @param pEntity Entity instance
   * @param pFieldMappers Field mappers
   * @param pPath Resource path
   */
  public EntityResource(ResourceResolver pResourceResolver, Object pEntity,
      List<FieldMapper> pFieldMappers, String pPath) {
    super(pPath,
        createValueMap(pEntity, pFieldMappers, null),
        null, pResourceResolver);
    mEntity = pEntity;
    mFieldMappers = pFieldMappers;
  }

  private static ValueMap createValueMap(Object pEntity, List<FieldMapper> pFieldMappers, String pResourceType) {
    return new EntityPropertyValueMap(pEntity, pFieldMappers, pResourceType);
  }

  private static String createResourceType(Class pEntityClass, String pResourceTypePrefix) {
    return pResourceTypePrefix + "/" + EntityUtil.getTableName(pEntityClass) + "/row";
  }

  /**
   * Builds resource path from id(s) of row
   * @param pParentPath Parent path
   * @param pEntity Entity
   * @param pFieldMappsers Field mappers
   * @return Resource path
   */
  private static String buildPathFromIds(String pParentPath, Object pEntity, List<FieldMapper> pFieldMappsers) {
    String idString = null;
    for (FieldMapper fieldMapper : pFieldMappsers) {
      if (fieldMapper.isIsId()) {
        if (idString!=null) {
          throw new RuntimeException("Multiple id columns found in entity: " + pEntity);
        }
        try {
          Object value = fieldMapper.getField().get(pEntity);
          if (value==null) {
            idString = "null";
          }
          else {
            idString = value.toString();
          }
        }
        catch (IllegalAccessException ex) {
          throw new RuntimeException("Cannot access value of field: " + fieldMapper.getField().getName(), ex);
        }
      }
    }
    return pParentPath + "/" + idString;
  }

  @SuppressWarnings("unchecked")
  @Override
  public <AdapterType> AdapterType adaptTo(Class<AdapterType> pType) {
    if (pType==ModifiableValueMap.class) {
      return (AdapterType)this.adaptTo(ValueMap.class);
    }
    return super.adaptTo(pType);
  }

  /**
   * List join column entities as children.
   * @param pEntityManager Entity manager
   * @param pResourceResolver Resourcer resolver
   * @return Child resources
   */
  public Iterator<Resource> listChildren(EntityManager pEntityManager, ResourceResolver pResourceResolver) {
    /*
    --- this is rather experimental and does not work yet as expected ---
    List<Resource> children = new ArrayList<Resource>();
    for (FieldMapper fieldMapper : mFieldMappers) {
      if (fieldMapper.isJoin()) {
        Object joinEntity = null;
        try {
          joinEntity = fieldMapper.getField().get(mEntity);
        }
        catch (IllegalArgumentException ex) {
          throw new RuntimeException("Unable to access field '" + fieldMapper.getName() + "'.", ex);
        }
        catch (IllegalAccessException ex) {
          throw new RuntimeException("Unable to access field '" + fieldMapper.getName() + "'.", ex);
        }
        if (joinEntity!=null) {
          // TODO: detect correct class form join entity, cache parsing of field mappers in central class
          //List<FieldMapper> fieldMappers = FieldMapper.getFieldMappers(joinEntity.getClass());
          List<FieldMapper> fieldMappers = FieldMapper.getFieldMappers(ProductLine.class);
          children.add(new EntityResource(pResourceResolver, joinEntity, fieldMappers, getPath() + "/" + fieldMapper.getName()));
        }
      }
    }
    return children.iterator();
    */
    return null;
  }

}
