package org.adaptto.slingrdbms.valuemap;

import java.util.List;

import org.adaptto.slingrdbms.resourceprovider.FieldMapper;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.wrappers.ValueMapDecorator;

/**
 * Virtual value map reading/writing entity properties.
 */
public class EntityPropertyValueMap extends ValueMapDecorator implements ModifiableValueMap {

  /**
   * @param pEntity Entity
   * @param pFieldMappers Field mappers
   * @param pResourceType Resource type
   */
  public EntityPropertyValueMap(Object pEntity, List<FieldMapper> pFieldMappers, String pResourceType) {
    super(new PropertyMap(pEntity, pFieldMappers, pResourceType));
  }

}
