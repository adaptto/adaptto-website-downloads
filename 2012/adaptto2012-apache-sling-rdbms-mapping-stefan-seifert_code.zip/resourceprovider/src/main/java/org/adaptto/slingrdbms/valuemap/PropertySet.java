package org.adaptto.slingrdbms.valuemap;

import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.adaptto.slingrdbms.resourceprovider.FieldMapper;

/**
 * Virtual set which represents all table fields as entires, plus one (read-only) extra entry for the resource type.
 */
class PropertySet extends AbstractSet<Map.Entry<String,Object>> {

  private final List<FieldEntry> mFieldEntries;
  private final String mResourceType;

  public PropertySet(Object pEntity, Map<String,FieldMapper> pFieldMappers, String pResourceType) {
    mFieldEntries = new ArrayList<FieldEntry>();
    for (FieldMapper fieldMapper : pFieldMappers.values()) {
      FieldEntry fieldEntry = new FieldEntry(fieldMapper, pEntity);
      // skip properties with empty value
      if (fieldEntry.getValue()!=null && !"".equals(fieldEntry.getValue())) {
        mFieldEntries.add(fieldEntry);
      }
    }
    mResourceType = pResourceType;
  }

  @Override
  public Iterator<Entry<String, Object>> iterator() {
    final Iterator<FieldEntry> fieldEntries = mFieldEntries.iterator();
    return new Iterator<Entry<String, Object>>() {

      private boolean mResourceTypeEntry = (mResourceType!=null);
      private FieldEntry mLastFieldEntry = null;

      @Override
      public boolean hasNext() {
        if (mResourceTypeEntry) {
          return true;
        }
        else {
          return fieldEntries.hasNext();
        }
      }

      @Override
      public Entry<String, Object> next() {
        if (mResourceTypeEntry) {
          mResourceTypeEntry = false;
          return new ResourceTypeEntry(mResourceType);
        }
        else {
          final FieldEntry fieldEntry = fieldEntries.next();
          if (fieldEntry==null) {
            return null;
          }
          mLastFieldEntry = fieldEntry;
          return fieldEntry;
        }
      }

      @Override
      public void remove() {
        if (mLastFieldEntry!=null) {
          mLastFieldEntry.setValue(null);
        }
        else {
          throw new IllegalStateException("remove() has already been called, or next() has not yet been called.");
        }
      }

    };
  }

  @Override
  public int size() {
    return mFieldEntries.size() + (mResourceType!=null ? 1 : 0);  // plus 1 because of resourceType propert
  }

}
