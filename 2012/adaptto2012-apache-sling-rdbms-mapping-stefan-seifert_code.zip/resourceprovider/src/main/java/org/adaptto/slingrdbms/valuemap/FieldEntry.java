package org.adaptto.slingrdbms.valuemap;

import java.lang.reflect.Field;
import java.util.Map;

import org.adaptto.slingrdbms.resourceprovider.FieldMapper;

/**
 * Read/write map entry for a single database field in one record/entity.
 */
class FieldEntry implements Map.Entry<String,Object> {

  private final FieldMapper mFieldMapper;
  private final Object mEntity;

  public FieldEntry(FieldMapper pFieldMapper, Object pEntity) {
    mFieldMapper = pFieldMapper;
    mEntity = pEntity;
  }

  @Override
  public String getKey() {
    return mFieldMapper.getName();
  }

  @Override
  public Object getValue() {
    try {
      return mFieldMapper.getField().get(mEntity);
    }
    catch (IllegalAccessException ex) {
      throw new RuntimeException(ex);
    }
  }

  @Override
  public Object setValue(Object pValue) {
    try {
      Object previousValue = mFieldMapper.getField().get(mEntity);
      Field field = mFieldMapper.getField();
      if (pValue==null || "".equals(pValue)) {
        field.set(mEntity, null);
      }
      else if (field.getType().isAssignableFrom(pValue.getClass())) {
        field.set(mEntity, pValue);
      }
      else if (field.getType() == String.class) {
        field.set(mEntity, String.valueOf(pValue));
      }
      else if (field.getType() == Integer.class) {
        field.set(mEntity, Integer.parseInt(pValue.toString()));
      }
      else if (field.getType() == Long.class) {
        field.set(mEntity, Long.parseLong(pValue.toString()));
      }
      else if (field.getType() == Float.class) {
        field.set(mEntity, Float.parseFloat(pValue.toString()));
      }
      else if (field.getType() == Double.class) {
        field.set(mEntity, Double.parseDouble(pValue.toString()));
      }
      else if (field.getType() == Boolean.class) {
        field.set(mEntity, Boolean.parseBoolean(pValue.toString()));
      }
      else {
        throw new IllegalArgumentException("Unsupported value type: " + pValue.getClass());
      }
      return previousValue;
    }
    catch (IllegalAccessException ex) {
      throw new RuntimeException(ex);
    }
  }

}
