package org.adaptto.slingrdbms.valuemap;

import java.util.Map;

import org.apache.sling.api.SlingConstants;

/**
 * Read-only map entry for resource type property. Set is allowed, but will be ignored.
 */
class ResourceTypeEntry implements Map.Entry<String,Object> {

  public static final String PROPERTY_NAME = SlingConstants.NAMESPACE_PREFIX + ":" + SlingConstants.PROPERTY_RESOURCE_TYPE;

  private final String mResorceType;

  public ResourceTypeEntry(String pResorceType) {
    mResorceType = pResorceType;
  }

  @Override
  public String getKey() {
    return PROPERTY_NAME;
  }

  @Override
  public Object getValue() {
    return mResorceType;
  }

  @Override
  public Object setValue(Object pValue) {
    // ignore, return old value
    return getValue();
  }

}
