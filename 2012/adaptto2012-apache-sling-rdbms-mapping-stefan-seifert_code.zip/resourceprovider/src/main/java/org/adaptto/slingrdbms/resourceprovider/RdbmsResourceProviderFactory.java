package org.adaptto.slingrdbms.resourceprovider;

import java.util.Arrays;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.adaptto.slingrdbms.entities.EntityManagerProvider;
import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.QueriableResourceProvider;
import org.apache.sling.api.resource.ResourceProvider;
import org.apache.sling.api.resource.ResourceProviderFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.hibernate.service.spi.ServiceException;
import org.osgi.framework.BundleContext;
import org.osgi.framework.InvalidSyntaxException;
import org.osgi.framework.ServiceReference;
import org.osgi.service.component.ComponentContext;

/**
 * RDBMS resource provider factory
 */
@Component(
    metatype=true,
    label="adaptto Sling&RDBMS Resource Provider Factory",
    description="Maps database tables to resource tree",
    configurationFactory=true
)
@Service(value=ResourceProviderFactory.class)
@Properties({
  @Property(
      name=ResourceProvider.ROOTS,
      label="Roots",
      description="Root path(s)"
  ),
  @Property(
      name=EntityManagerProvider.PROPERTY_DATASOURCE_NAME,
      label="Datasource",
      description="Datasource name"
  ),
  @Property(
      name=RdbmsResourceProviderFactory.PROPERTY_ENTITY_CLASS,
      label="JPA Entity",
      description="JPA Entity class name"
  ),
  @Property(
      name=RdbmsResourceProviderFactory.PROPERTY_RESOURCETYPE_PREFIX,
      label="Resourcetype Prefix",
      description="Prefix that is used to buid source types for tabel and rows",
      value="/rdbms/table"
  ),
  @Property(
      name=QueriableResourceProvider.LANGUAGES,
      label="Query languages",
      description="Query langauges supported by resources provider.",
      value={RdbmsResourceProvider.QUERY_LANGUAGE_JPAQL}
  )
})
public class RdbmsResourceProviderFactory implements ResourceProviderFactory {

  protected static final String PROPERTY_ENTITY_CLASS = "entity.class";
  protected static final String PROPERTY_RESOURCETYPE_PREFIX = "resourcetype.prefix";

  /**
   * This is used to separate id values in paths if an entity has multiple IDs.
   */
  public static final String ID_SEPARATOR = "~";

  private BundleContext mBundleContext;
  private ServiceReference mEntityManagerProviderServiceReference;
  private EntityManagerProvider mEntityManagerProvider;
  private Class mEntityClass;
  private String mResourceTypePrefix;
  private List<FieldMapper> mFieldMappers;
  private Set<String> mRootPaths;

  @Activate
  protected synchronized void activate(ComponentContext pComponentContext)
      throws InvalidSyntaxException, ClassNotFoundException {
    Dictionary serviceProperties = pComponentContext.getProperties();
    String datasourceName = PropertiesUtil.toString(serviceProperties.get(EntityManagerProvider.PROPERTY_DATASOURCE_NAME), null);

    // get reference to entity manager provider
    mBundleContext = pComponentContext.getBundleContext();
    ServiceReference[] serviceReferences = mBundleContext.getServiceReferences(EntityManagerProvider.class.getName(),
        "(" + EntityManagerProvider.PROPERTY_DATASOURCE_NAME + "=" + datasourceName + ")");
    if (serviceReferences==null || serviceReferences.length==0) {
      throw new ServiceException("No entity manager provider found four data source: " + datasourceName);
    }
    if (serviceReferences.length>1) {
      throw new ServiceException("Multiple entity manager providers found four data source: " + datasourceName);
    }
    mEntityManagerProviderServiceReference = serviceReferences[0];
    mEntityManagerProvider = (EntityManagerProvider)mBundleContext.getService(mEntityManagerProviderServiceReference);

    // get entity class
    String entityClassName = PropertiesUtil.toString(serviceProperties.get(PROPERTY_ENTITY_CLASS), null);
    mEntityClass = getClass().getClassLoader().loadClass(entityClassName);
    mResourceTypePrefix = PropertiesUtil.toString(serviceProperties.get(PROPERTY_RESOURCETYPE_PREFIX), null);

    // initialize field mappers for entity
    mFieldMappers = FieldMapper.getFieldMappers(mEntityClass);

    // get root paths
    String[] rootPaths = PropertiesUtil.toStringArray(serviceProperties.get(ResourceProvider.ROOTS));
    mRootPaths = new HashSet<String>(Arrays.asList(rootPaths));
  }

  @Deactivate
  protected synchronized void deactivate(ComponentContext pComponentContext) {
    if (mEntityManagerProviderServiceReference!=null) {
      mEntityManagerProvider = null;
      mBundleContext.ungetService(mEntityManagerProviderServiceReference);
    }
  }

  @Override
  public ResourceProvider getResourceProvider(Map<String, Object> pAuthenticationInfo) throws LoginException {
    // authentication is taken from service properties, authentication info is ignored
    return new RdbmsResourceProvider(mEntityManagerProvider.createEntityManager(), mEntityClass, mResourceTypePrefix, mFieldMappers, mRootPaths);
  }

  @Override
  public ResourceProvider getAdministrativeResourceProvider(Map<String, Object> pAuthenticationInfo) throws LoginException {
    return getResourceProvider(pAuthenticationInfo);
  }

}
