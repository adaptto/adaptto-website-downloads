package org.adaptto.slingrdbms.resourceprovider;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import org.apache.commons.lang.StringUtils;

/**
 * Helper class for mapping JPA field annotations
 */
public class FieldMapper {

  private final String mName;
  private final boolean mIsId;
  private final boolean mIsJoin;
  private final Field mField;

  /**
   * @param pField Field
   */
  public FieldMapper(Field pField) {
    if (pField.isAnnotationPresent(Column.class)) {
      Column column = pField.getAnnotation(Column.class);
      mIsJoin = false;
      mName = column.name();
    }
    else if (pField.isAnnotationPresent(JoinColumn.class)) {
      JoinColumn column = pField.getAnnotation(JoinColumn.class);
      mIsJoin = true;
      mName = column.name();
    }
    else {
      mName = null;
      mIsJoin = false;
    }
    mIsId = pField.isAnnotationPresent(Id.class);
    mField = pField;
    mField.setAccessible(true);
  }

  /**
   * @return Field is valid JPA field
   */
  public boolean isValid() {
    return StringUtils.isNotEmpty(mName);
  }

  /**
   * @return Field name in database
   */
  public String getName() {
    return mName;
  }

  /**
   * @return Field is identifier
   */
  public boolean isIsId() {
    return mIsId;
  }

  /**
   * @return Field is a join column
   */
  public boolean isJoin() {
    return mIsJoin;
  }

  /**
   * @return Field
   */
  public Field getField() {
    return mField;
  }

  /**
   * Get field mappers for entity class
   * @param pEntityClass Entity class
   * @return Field mappers
   */
  public static List<FieldMapper> getFieldMappers(Class pEntityClass) {
    List<FieldMapper> fieldMappers = new ArrayList<FieldMapper>();
    Field[] fields = pEntityClass.getDeclaredFields();
    for (Field field : fields) {
      FieldMapper mapper = new FieldMapper(field);
      if (mapper.isValid()) {
        fieldMappers.add(mapper);
      }
    }
    return fieldMappers;
  }

}
