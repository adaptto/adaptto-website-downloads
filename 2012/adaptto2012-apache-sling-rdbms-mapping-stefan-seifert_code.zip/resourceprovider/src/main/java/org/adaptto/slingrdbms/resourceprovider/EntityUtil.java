package org.adaptto.slingrdbms.resourceprovider;

import javax.persistence.Table;

/**
 * Helper methods
 */
public class EntityUtil {

  private EntityUtil() {
    // static methods only
  }

  /**
   * @param pEntityClass Entity class
   * @return Table name or null
   */
  @SuppressWarnings("unchecked")
  public static String getTableName(Class pEntityClass) {
    if (pEntityClass.isAnnotationPresent(Table.class)) {
      Table table = (Table)pEntityClass.getAnnotation(Table.class);
      if (table!=null) {
        return table.name();
      }
    }
    return null;
  }

}
