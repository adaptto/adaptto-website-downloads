package org.adaptto.slingrdbms.resourceprovider;

import org.apache.sling.api.resource.AbstractResource;
import org.apache.sling.api.resource.ResourceMetadata;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;

/**
 * Abstract RDBMS resource implementation
 */
abstract class AbstractRdbmsResource extends AbstractResource {

  private final String mPath;
  private final String mResourceType;
  private final ResourceResolver mResourceResolver;
  private final ResourceMetadata mResourceMetadata;
  private final ValueMap mProperties;

  protected AbstractRdbmsResource(String pPath, ValueMap pValueMap,
      String pResourceType, ResourceResolver pResourceResolver) {
    mPath = pPath;
    mResourceType = pResourceType;
    mResourceResolver = pResourceResolver;
    mResourceMetadata = new ResourceMetadata();
    mResourceMetadata.setResolutionPath(pPath);
    mProperties = pValueMap;
  }

  @Override
  public String getPath() {
    return mPath;
  }

  @Override
  public String getResourceType() {
    return mResourceType;
  }

  @Override
  public String getResourceSuperType() {
    return null;
  }

  @Override
  public ResourceMetadata getResourceMetadata() {
    return mResourceMetadata;
  }

  @Override
  public ResourceResolver getResourceResolver() {
    return mResourceResolver;
  }

  @SuppressWarnings("unchecked")
  @Override
  public <AdapterType> AdapterType adaptTo(Class<AdapterType> pType) {
    if (pType==ValueMap.class) {
      return (AdapterType)mProperties;
    }
    else {
      return super.adaptTo(pType);
    }
  }

}
