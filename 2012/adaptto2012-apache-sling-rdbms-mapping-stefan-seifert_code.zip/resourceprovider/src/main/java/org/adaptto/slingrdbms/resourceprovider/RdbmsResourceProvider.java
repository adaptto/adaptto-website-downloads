package org.adaptto.slingrdbms.resourceprovider;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.sling.api.resource.DynamicResourceProvider;
import org.apache.sling.api.resource.ModifyingResourceProvider;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.QueriableResourceProvider;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceProvider;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * RDBMS resource provider
 *
 * TODO: map inline entites to child resources! query them together with main query (by config?)
 * TODO: solution for master/detail scenarios
 */
class RdbmsResourceProvider implements ResourceProvider, ModifyingResourceProvider,
    DynamicResourceProvider, QueriableResourceProvider {

  /**
   * JPA query language
   */
  public static final String QUERY_LANGUAGE_JPAQL = "jpaql";

  private final Logger mLog = LoggerFactory.getLogger(getClass());

  /**
   * This is used to separate id values in paths if an entity has multiple IDs.
   */
  public static final String ID_SEPARATOR = "~";

  private EntityManager mEntityManager;
  private Class mEntityClass;
  private String mResourceTypePrefix;
  private List<FieldMapper> mFieldMappers;
  private Set<String> mRootPaths;

  public RdbmsResourceProvider(EntityManager pEntityManager, Class pEntityClass, String pResourceTypePrefix, List<FieldMapper> pFieldMappers,
      Set<String> pRootPaths) {
    mEntityManager = pEntityManager;
    mEntityClass = pEntityClass;
    mResourceTypePrefix = pResourceTypePrefix;
    mFieldMappers = pFieldMappers;
    mRootPaths = pRootPaths;

    // begin implicit transaction
    mEntityManager.getTransaction().begin();
  }

  @Override
  public Resource getResource(ResourceResolver pResourceResolver, HttpServletRequest pRequest, String pPath) {
    return getResource(pResourceResolver, pPath);
  }

  @Override
  public Resource getResource(ResourceResolver pResourceResolver, String pPath) {
    mLog.debug("getResource: {}", pPath);
    // root path = root resource
    if (mRootPaths.contains(pPath)) {
      return new RootResource(pPath, pResourceResolver, mEntityClass, mFieldMappers, mResourceTypePrefix);
    }
    else {
      Object entity = getEntityByPath(pPath);
      if (entity!=null) {
        return new EntityResource(pResourceResolver, entity, mFieldMappers, mResourceTypePrefix, ResourceUtil.getParent(pPath));
      }
    }
    return null;
  }

  @SuppressWarnings("unchecked")
  private Object getEntityByPath(String pPath) {
    // get id part
    for (String rootPath : mRootPaths) {
      if (StringUtils.startsWith(pPath, rootPath)) {
        String idString = StringUtils.substringAfter(pPath, rootPath + "/");
        if (StringUtils.isNotEmpty(idString)) {
          // find entity for id
          return mEntityManager.find(mEntityClass, idString);
        }
      }
    }
    return false;
  }

  @Override
  public Iterator<Resource> listChildren(Resource pParent) {
    mLog.debug("listChildren: {}", pParent.getPath());
    if (pParent instanceof RootResource) {
      RootResource rootResource = (RootResource)pParent;
      return rootResource.listChildren(mEntityManager);
    }
    else if (pParent instanceof EntityResource) {
      EntityResource entityResource = (EntityResource)pParent;
      return entityResource.listChildren(mEntityManager, pParent.getResourceResolver());
    }
    return null;
  }

  @Override
  public Resource create(ResourceResolver pResolver, String pPath, Map<String, Object> pProperties) throws PersistenceException {
    try {
      Object entity = mEntityClass.newInstance();
      Resource resource = new EntityResource(pResolver, entity, mFieldMappers, mResourceTypePrefix, ResourceUtil.getParent(pPath));
      ValueMap valueMap = resource.adaptTo(ValueMap.class);
      valueMap.putAll(pProperties);
      mEntityManager.persist(entity);
      return resource;
    }
    catch (InstantiationException ex) {
      throw new PersistenceException("Error creating entity.", ex);
    }
    catch (IllegalAccessException ex) {
      throw new PersistenceException("Error creating entity.", ex);
    }
  }

  @Override
  public void delete(ResourceResolver pResolver, String pPath) throws PersistenceException {
    Object entity = getEntityByPath(pPath);
    if (entity!=null) {
      mEntityManager.remove(entity);
    }
  }

  @Override
  public void revert(ResourceResolver pResolver) {
    EntityTransaction transaction = mEntityManager.getTransaction();
    if (transaction.isActive()) {
      transaction.rollback();
    }
    // start next implicit transaction
    transaction.begin();
  }

  @Override
  public void commit(ResourceResolver pResolver) throws PersistenceException {
    EntityTransaction transaction = mEntityManager.getTransaction();
    if (transaction.isActive()) {
      transaction.commit();
    }
    // start next implicit transaction
    transaction.begin();
  }

  @Override
  public boolean hasChanges(ResourceResolver pResolver) {
    // TODO: how to detect if the entity manager has pending changes? it provides no such method.
    return false;
  }

  @Override
  public boolean isLive() {
    return mEntityManager.isOpen();
  }

  @Override
  public void close() {
    // rollback uncommitted transactions
    if (mEntityManager.getTransaction().isActive()) {
      mEntityManager.getTransaction().rollback();
    }
    mEntityManager.close();
  }

  @SuppressWarnings("unchecked")
  @Override
  public Iterator<Resource> findResources(final ResourceResolver pResolver, String pQuery, String pLanguage) {
    if (StringUtils.equals(pLanguage, QUERY_LANGUAGE_JPAQL)) {
      Query query = mEntityManager.createQuery(pQuery);
      final Iterator<Object> resultIterator = query.getResultList().iterator();
      return new Iterator<Resource>() {

        @Override
        public boolean hasNext() {
          return resultIterator.hasNext();
        }

        @Override
        public Resource next() {
          Object entity = resultIterator.next();
          return new EntityResource(pResolver, entity, mFieldMappers, mResourceTypePrefix, mRootPaths.iterator().next());
        }

        @Override
        public void remove() {
          throw new UnsupportedOperationException();
        }

      };
    }
    else {
      throw new IllegalArgumentException("Query language '" + pLanguage + "' not supported.");
    }
  }

  @Override
  public Iterator<Map<String, Object>> queryResources(ResourceResolver pResolver, String pQuery, String pLanguage) {
    final Iterator<Resource> resourceIterator = findResources(pResolver, pQuery, pLanguage);
    return new Iterator<Map<String, Object>>() {

      @Override
      public boolean hasNext() {
        return resourceIterator.hasNext();
      }

      @Override
      public Map<String, Object> next() {
        return resourceIterator.next().adaptTo(ValueMap.class);
      }

      @Override
      public void remove() {
        throw new UnsupportedOperationException();
      }

    };
  }

}
