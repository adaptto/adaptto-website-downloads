package org.adaptto.slingrdbms.valuemap;

import java.util.AbstractMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.adaptto.slingrdbms.resourceprovider.FieldMapper;
import org.apache.commons.lang.StringUtils;

/**
 * Virtual map reading/writing entity properties.
 */
class PropertyMap extends AbstractMap<String,Object> {

  private final Object mEntity;
  private final Map<String,FieldMapper> mFieldMappers;
  private final PropertySet mEntrySet;
  private final String mResourceType;

  public PropertyMap(Object pEntity, List<FieldMapper> pFieldMappers, String pResourceType) {
    mEntity = pEntity;
    mFieldMappers = new HashMap<String,FieldMapper>();
    for (FieldMapper fieldMapper : pFieldMappers) {
      // skip join columns in property map, they are handled as child resources
      if (!fieldMapper.isJoin()) {
        mFieldMappers.put(fieldMapper.getName(), fieldMapper);
      }
    }
    mEntrySet = new PropertySet(pEntity, mFieldMappers, pResourceType);
    mResourceType = pResourceType;
  }

  @Override
  public Set<Map.Entry<String, Object>> entrySet() {
    return mEntrySet;
  }

  @Override
  public Object put(String pKey, Object pValue) {
    if (StringUtils.equals(pKey, ResourceTypeEntry.PROPERTY_NAME)) {
      return new ResourceTypeEntry(mResourceType);
    }
    else {
      FieldMapper fieldMapper = mFieldMappers.get(pKey);
      if (fieldMapper==null) {
        throw new IllegalArgumentException("Field '" + pKey + "' does not exist.");
      }
      return new FieldEntry(fieldMapper, mEntity).setValue(pValue);
    }
  }

}
