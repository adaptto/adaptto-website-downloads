package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * Entity 'Orders'
 */
@Entity
@Table(name = "Orders")
public class Order implements java.io.Serializable {
  private static final long serialVersionUID = 1473380209L;

  @Id
  @Column(name = "orderNumber", nullable=false)
  private Integer orderNumber = 0;

  @Column(name = "orderDate", nullable=false)
  private java.util.Date orderDate = null;

  @Column(name = "requiredDate")
  private java.util.Date requiredDate = null;

  @Column(name = "shippedDate")
  private java.util.Date shippedDate = null;

  @Column(name = "status", length=15)
  private String status = "";

  @Lob
  @Column(name = "comments")
  private String comments = "";

  @Column(name = "customerNumber")
  private Integer customerNumber = 0;



  /**
   * Initializes a new <code>Orders</code> object.
   */
  public Order() {
    // empty constructor
  }

  /**
   * Attribute 'orderNumber'. Required.
   * @return Attribute value.
   */
  public int getOrderNumber() {
    return this.orderNumber!=null ? this.orderNumber : 0;
  }

  /**
   * Attribute 'orderNumber'. Required.
   * @param pValue Attribute value.
   */
  public void setOrderNumber(int pValue) {
    this.orderNumber = pValue;
  }

  /**
   * Attribute 'orderDate'.
   * @return Attribute value.
   */
  public java.util.Date getOrderDate() {
    return this.orderDate;
  }

  /**
   * Attribute 'orderDate'.
   * @param pValue Attribute value.
   */
  public void setOrderDate(java.util.Date pValue) {
    this.orderDate = pValue;
  }

  /**
   * Attribute 'requiredDate'.
   * @return Attribute value.
   */
  public java.util.Date getRequiredDate() {
    return this.requiredDate;
  }

  /**
   * Attribute 'requiredDate'.
   * @param pValue Attribute value.
   */
  public void setRequiredDate(java.util.Date pValue) {
    this.requiredDate = pValue;
  }

  /**
   * Attribute 'shippedDate'.
   * @return Attribute value.
   */
  public java.util.Date getShippedDate() {
    return this.shippedDate;
  }

  /**
   * Attribute 'shippedDate'.
   * @param pValue Attribute value.
   */
  public void setShippedDate(java.util.Date pValue) {
    this.shippedDate = pValue;
  }

  /**
   * In Process, Shipped, Cancelled, Disputed, Paid
   * @return Attribute value.
   */
  public String getStatus() {
    return this.status;
  }

  /**
   * In Process, Shipped, Cancelled, Disputed, Paid
   * @param pValue Attribute value.
   */
  public void setStatus(String pValue) {
    this.status = pValue;
  }

  /**
   * Why is the order cancelled
   * @return Attribute value.
   */
  public String getComments() {
    return this.comments;
  }

  /**
   * Why is the order cancelled
   * @param pValue Attribute value.
   */
  public void setComments(String pValue) {
    this.comments = pValue;
  }

  /**
   * Attribute 'customerNumber'.
   * @return Attribute value.
   */
  public int getCustomerNumber() {
    return this.customerNumber!=null ? this.customerNumber : 0;
  }

  /**
   * Attribute 'customerNumber'.
   * @param pValue Attribute value.
   */
  public void setCustomerNumber(int pValue) {
    this.customerNumber = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Order)) {
      return false;
    }
    if (getOrderNumber() == 0) {
      return this == pOther;
    }
    return getOrderNumber() == ((Order)pOther).getOrderNumber();
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getOrderNumber();
    return result;
  }

}
