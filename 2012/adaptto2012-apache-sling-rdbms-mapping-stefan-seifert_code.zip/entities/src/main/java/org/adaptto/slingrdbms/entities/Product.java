package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entity 'Products'
 */
@Entity
@Table(name = "Products")
public class Product implements java.io.Serializable {
  private static final long serialVersionUID = 1199782026L;

  @Id
  @Column(name = "productCode", length=15, nullable=false)
  private String productCode = "";

  @Column(name = "productName", length=70, nullable=false)
  private String productName = "";

  @ManyToOne(fetch=FetchType.LAZY, optional=true)
  @JoinColumn(name = "productLine")
  private ProductLine productLine = null;

  @Column(name = "productScale", length=10)
  private String productScale = "";

  @Column(name = "productVendor", length=50)
  private String productVendor = "";

  @Lob
  @Column(name = "productDescription")
  private String productDescription = "";

  @Column(name = "quantityInStock")
  private Integer quantityInStock = 0;

  @Column(name = "buyPrice")
  private Double buyPrice = 0d;

  @Column(name = "MSRP")
  private Double MSRP = 0d;


  /**
   * Initializes a new <code>Products</code> object.
   */
  public Product() {
    // empty constructor
  }

  /**
   * Attribute 'productCode'. Required.
   * @return Attribute value.
   */
  public String getProductCode() {
    return this.productCode;
  }

  /**
   * Attribute 'productCode'. Required.
   * @param pValue Attribute value.
   */
  public void setProductCode(String pValue) {
    this.productCode = pValue;
  }

  /**
   * Attribute 'productName'.
   * @return Attribute value.
   */
  public String getProductName() {
    return this.productName;
  }

  /**
   * Attribute 'productName'.
   * @param pValue Attribute value.
   */
  public void setProductName(String pValue) {
    this.productName = pValue;
  }

  /**
   * Attribute 'productLine'.
   * @return Attribute value.
   */
  public ProductLine getProductLine() {
    return this.productLine;
  }

  /**
   * Attribute 'productLine'.
   * @param pValue Attribute value.
   */
  public void setProductLine(ProductLine pValue) {
    this.productLine = pValue;
  }

  /**
   * Attribute 'productScale'.
   * @return Attribute value.
   */
  public String getProductScale() {
    return this.productScale;
  }

  /**
   * Attribute 'productScale'.
   * @param pValue Attribute value.
   */
  public void setProductScale(String pValue) {
    this.productScale = pValue;
  }

  /**
   * Attribute 'productVendor'.
   * @return Attribute value.
   */
  public String getProductVendor() {
    return this.productVendor;
  }

  /**
   * Attribute 'productVendor'.
   * @param pValue Attribute value.
   */
  public void setProductVendor(String pValue) {
    this.productVendor = pValue;
  }

  /**
   * Attribute 'productDescription'.
   * @return Attribute value.
   */
  public String getProductDescription() {
    return this.productDescription;
  }

  /**
   * Attribute 'productDescription'.
   * @param pValue Attribute value.
   */
  public void setProductDescription(String pValue) {
    this.productDescription = pValue;
  }

  /**
   * Attribute 'quantityInStock'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public int getQuantityInStock() {
    return this.quantityInStock!=null ? this.quantityInStock : 0;
  }

  /**
   * Attribute 'quantityInStock'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setQuantityInStock(int pValue) {
    this.quantityInStock = pValue;
  }

  /**
   * Attribute 'buyPrice'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public double getBuyPrice() {
    return this.buyPrice!=null ? this.buyPrice : 0d;
  }

  /**
   * Attribute 'buyPrice'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setBuyPrice(double pValue) {
    this.buyPrice = pValue;
  }

  /**
   * Attribute 'MSRP'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public double getMSRP() {
    return this.MSRP!=null ? this.MSRP : 0d;
  }

  /**
   * Attribute 'MSRP'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setMSRP(double pValue) {
    this.MSRP = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Product)) {
      return false;
    }
    if (getProductCode() == null) {
      return this == pOther;
    }
    return getProductCode().equals(((Product)pOther).getProductCode());
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getProductCode().hashCode();
    return result;
  }

}
