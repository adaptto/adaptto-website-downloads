package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * Entity 'ProductLines'
 */
@Entity
@Table(name = "ProductLines")
public class ProductLine implements java.io.Serializable {
  private static final long serialVersionUID = 676265793L;

  @Id
  @Column(name = "productLine", length=50, nullable=false)
  private String productLine = "";

  @Lob
  @Column(name = "textDescription")
  private String textDescription = "";

  @Lob
  @Column(name = "htmlDescription")
  private String htmlDescription = "";

  @Lob
  @Column(name = "image")
  private byte[] image = null;



  /**
   * Initializes a new <code>ProductLines</code> object.
   */
  public ProductLine() {
    // empty constructor
  }

  /**
   * Attribute 'productLine'. Required.
   * @return Attribute value.
   */
  public String getProductLine() {
    return this.productLine;
  }

  /**
   * Attribute 'productLine'. Required.
   * @param pValue Attribute value.
   */
  public void setProductLine(String pValue) {
    this.productLine = pValue;
  }

  /**
   * Attribute 'textDescription'.
   * @return Attribute value.
   */
  public String getTextDescription() {
    return this.textDescription;
  }

  /**
   * Attribute 'textDescription'.
   * @param pValue Attribute value.
   */
  public void setTextDescription(String pValue) {
    this.textDescription = pValue;
  }

  /**
   * Attribute 'htmlDescription'.
   * @return Attribute value.
   */
  public String getHtmlDescription() {
    return this.htmlDescription;
  }

  /**
   * Attribute 'htmlDescription'.
   * @param pValue Attribute value.
   */
  public void setHtmlDescription(String pValue) {
    this.htmlDescription = pValue;
  }

  /**
   * Attribute 'image'.
   * @return Attribute value.
   */
  public byte[] getImage() {
    return this.image;
  }

  /**
   * Attribute 'image'.
   * @param pValue Attribute value.
   */
  public void setImage(byte[] pValue) {
    this.image = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof ProductLine)) {
      return false;
    }
    if (getProductLine() == null) {
      return this == pOther;
    }
    return getProductLine().equals(((ProductLine)pOther).getProductLine());
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getProductLine().hashCode();
    return result;
  }

}
