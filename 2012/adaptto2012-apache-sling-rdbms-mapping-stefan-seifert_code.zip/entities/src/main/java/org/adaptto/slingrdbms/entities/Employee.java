package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entity 'Employees'
 */
@Entity
@Table(name = "Employees")
public class Employee implements java.io.Serializable {
  private static final long serialVersionUID = -993017731L;

  @Id
  @Column(name = "employeeNumber", nullable=false)
  private Integer employeeNumber = 0;

  @Column(name = "lastName", length=50, nullable=false)
  private String lastName = "";

  @Column(name = "firstName", length=50)
  private String firstName = "";

  @Column(name = "extension", length=10)
  private String extension = "";

  @Column(name = "email", length=100)
  private String email = "";

  @ManyToOne(fetch=FetchType.LAZY, optional=true)
  @JoinColumn(name = "officeCode")
  private Office office = null;

  @Column(name = "reportsTo")
  private Integer reportsTo = 0;

  @Column(name = "jobTitle", length=50)
  private String jobTitle = "";



  /**
   * Initializes a new <code>Employees</code> object.
   */
  public Employee() {
    // empty constructor
  }

  /**
   * Attribute 'employeeNumber'. Required.
   * @return Attribute value.
   */
  public int getEmployeeNumber() {
    return this.employeeNumber!=null ? this.employeeNumber : 0;
  }

  /**
   * Attribute 'employeeNumber'. Required.
   * @param pValue Attribute value.
   */
  public void setEmployeeNumber(int pValue) {
    this.employeeNumber = pValue;
  }

  /**
   * Attribute 'lastName'.
   * @return Attribute value.
   */
  public String getLastName() {
    return this.lastName;
  }

  /**
   * Attribute 'lastName'.
   * @param pValue Attribute value.
   */
  public void setLastName(String pValue) {
    this.lastName = pValue;
  }

  /**
   * Attribute 'firstName'.
   * @return Attribute value.
   */
  public String getFirstName() {
    return this.firstName;
  }

  /**
   * Attribute 'firstName'.
   * @param pValue Attribute value.
   */
  public void setFirstName(String pValue) {
    this.firstName = pValue;
  }

  /**
   * Attribute 'extension'.
   * @return Attribute value.
   */
  public String getExtension() {
    return this.extension;
  }

  /**
   * Attribute 'extension'.
   * @param pValue Attribute value.
   */
  public void setExtension(String pValue) {
    this.extension = pValue;
  }

  /**
   * Attribute 'email'.
   * @return Attribute value.
   */
  public String getEmail() {
    return this.email;
  }

  /**
   * Attribute 'email'.
   * @param pValue Attribute value.
   */
  public void setEmail(String pValue) {
    this.email = pValue;
  }

  /**
   * Attribute 'officeCode'.
   * @return Attribute value.
   */
  public Office getOffice() {
    return this.office;
  }

  /**
   * Attribute 'officeCode'.
   * @param pValue Attribute value.
   */
  public void setOffice(Office pValue) {
    this.office = pValue;
  }

  /**
   * Links to employeeNumber; allows for hierarchies to be defined<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public int getReportsTo() {
    return this.reportsTo!=null ? this.reportsTo : 0;
  }

  /**
   * Links to employeeNumber; allows for hierarchies to be defined<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setReportsTo(int pValue) {
    this.reportsTo = pValue;
  }

  /**
   * Senior Sales Rep, Sales Manager etc.
   * @return Attribute value.
   */
  public String getJobTitle() {
    return this.jobTitle;
  }

  /**
   * Senior Sales Rep, Sales Manager etc.
   * @param pValue Attribute value.
   */
  public void setJobTitle(String pValue) {
    this.jobTitle = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Employee)) {
      return false;
    }
    if (getEmployeeNumber() == 0) {
      return this == pOther;
    }
    return getEmployeeNumber() == ((Employee)pOther).getEmployeeNumber();
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getEmployeeNumber();
    return result;
  }

}
