package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entity 'Payments'
 */
@Entity
@Table(name = "Payments")
public class Payment implements java.io.Serializable {
  private static final long serialVersionUID = -659613424L;

  @Id
  @ManyToOne(fetch=FetchType.LAZY, optional=false)
  @JoinColumn(name = "customerNumber", nullable=false)
  private Customer customerNumber = null;

  @Id
  @Column(name = "checkNumber", length=50, nullable=false)
  private String checkNumber = "";

  @Column(name = "paymentDate", nullable=false)
  private java.util.Date paymentDate = null;

  @Column(name = "amount", nullable=false)
  private Double amount = 0d;



  /**
   * Initializes a new <code>Payments</code> object.
   */
  public Payment() {
    // empty constructor
  }

  /**
   * Attribute 'customerNumber'. Required.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public Customer getCustomerNumber() {
    return this.customerNumber;
  }

  /**
   * Attribute 'customerNumber'. Required.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setCustomerNumber(Customer pValue) {
    this.customerNumber = pValue;
  }

  /**
   * Attribute 'checkNumber'.
   * @return Attribute value.
   */
  public String getCheckNumber() {
    return this.checkNumber;
  }

  /**
   * Attribute 'checkNumber'.
   * @param pValue Attribute value.
   */
  public void setCheckNumber(String pValue) {
    this.checkNumber = pValue;
  }

  /**
   * Attribute 'paymentDate'.
   * @return Attribute value.
   */
  public java.util.Date getPaymentDate() {
    return this.paymentDate;
  }

  /**
   * Attribute 'paymentDate'.
   * @param pValue Attribute value.
   */
  public void setPaymentDate(java.util.Date pValue) {
    this.paymentDate = pValue;
  }

  /**
   * Attribute 'amount'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public double getAmount() {
    return this.amount!=null ? this.amount : 0d;
  }

  /**
   * Attribute 'amount'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setAmount(double pValue) {
    this.amount = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Payment)) {
      return false;
    }
    if (getCustomerNumber()==null || getCheckNumber()==null) {
      return this == pOther;
    }
    return getCustomerNumber().equals(((Payment)pOther).getCustomerNumber())
        && getCheckNumber().equals(((Payment)pOther).getCheckNumber());
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getCustomerNumber().hashCode();
    result = 37*result + getCheckNumber().hashCode();
    return result;
  }

}
