package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity 'Customers'
 */
@Entity
@Table(name = "Customers")
public class Customer implements java.io.Serializable {
  private static final long serialVersionUID = -1088805682L;

  @Id
  @Column(name = "customerNumber", nullable=false)
  private Integer customerNumber = 0;

  @Column(name = "customerName", length=50, nullable=false)
  private String customerName = "";

  @Column(name = "contactLastName", length=50)
  private String contactLastName = "";

  @Column(name = "contactFirstName", length=50)
  private String contactFirstName = "";

  @Column(name = "phone", length=50)
  private String phone = "";

  @Column(name = "addressLine1", length=50)
  private String addressLine1 = "";

  @Column(name = "addressLine2", length=50)
  private String addressLine2 = "";

  @Column(name = "city", length=50)
  private String city = "";

  @Column(name = "state", length=15)
  private String state = "";

  @Column(name = "postalCode", length=15)
  private String postalCode = "";

  @Column(name = "country", length=50)
  private String country = "";

  @Column(name = "salesRepEmployeeNumber")
  private Integer salesRepEmployeeNumber = 0;

  @Column(name = "creditLimit")
  private Double creditLimit = 0d;



  /**
   * Initializes a new <code>Customers</code> object.
   */
  public Customer() {
    // empty constructor
  }

  /**
   * Attribute 'customerNumber'. Required.
   * @return Attribute value.
   */
  public int getCustomerNumber() {
    return this.customerNumber!=null ? this.customerNumber : 0;
  }

  /**
   * Attribute 'customerNumber'. Required.
   * @param pValue Attribute value.
   */
  public void setCustomerNumber(int pValue) {
    this.customerNumber = pValue;
  }

  /**
   * Attribute 'customerName'.
   * @return Attribute value.
   */
  public String getCustomerName() {
    return this.customerName;
  }

  /**
   * Attribute 'customerName'.
   * @param pValue Attribute value.
   */
  public void setCustomerName(String pValue) {
    this.customerName = pValue;
  }

  /**
   * Attribute 'contactLastName'.
   * @return Attribute value.
   */
  public String getContactLastName() {
    return this.contactLastName;
  }

  /**
   * Attribute 'contactLastName'.
   * @param pValue Attribute value.
   */
  public void setContactLastName(String pValue) {
    this.contactLastName = pValue;
  }

  /**
   * Attribute 'contactFirstName'.
   * @return Attribute value.
   */
  public String getContactFirstName() {
    return this.contactFirstName;
  }

  /**
   * Attribute 'contactFirstName'.
   * @param pValue Attribute value.
   */
  public void setContactFirstName(String pValue) {
    this.contactFirstName = pValue;
  }

  /**
   * Attribute 'phone'.
   * @return Attribute value.
   */
  public String getPhone() {
    return this.phone;
  }

  /**
   * Attribute 'phone'.
   * @param pValue Attribute value.
   */
  public void setPhone(String pValue) {
    this.phone = pValue;
  }

  /**
   * Attribute 'addressLine1'.
   * @return Attribute value.
   */
  public String getAddressLine1() {
    return this.addressLine1;
  }

  /**
   * Attribute 'addressLine1'.
   * @param pValue Attribute value.
   */
  public void setAddressLine1(String pValue) {
    this.addressLine1 = pValue;
  }

  /**
   * Attribute 'addressLine2'.
   * @return Attribute value.
   */
  public String getAddressLine2() {
    return this.addressLine2;
  }

  /**
   * Attribute 'addressLine2'.
   * @param pValue Attribute value.
   */
  public void setAddressLine2(String pValue) {
    this.addressLine2 = pValue;
  }

  /**
   * Attribute 'city'.
   * @return Attribute value.
   */
  public String getCity() {
    return this.city;
  }

  /**
   * Attribute 'city'.
   * @param pValue Attribute value.
   */
  public void setCity(String pValue) {
    this.city = pValue;
  }

  /**
   * Will represent states in US, provinces in Canada, areas in the UK etc.
   * @return Attribute value.
   */
  public String getState() {
    return this.state;
  }

  /**
   * Will represent states in US, provinces in Canada, areas in the UK etc.
   * @param pValue Attribute value.
   */
  public void setState(String pValue) {
    this.state = pValue;
  }

  /**
   * Attribute 'postalCode'.
   * @return Attribute value.
   */
  public String getPostalCode() {
    return this.postalCode;
  }

  /**
   * Attribute 'postalCode'.
   * @param pValue Attribute value.
   */
  public void setPostalCode(String pValue) {
    this.postalCode = pValue;
  }

  /**
   * Attribute 'country'.
   * @return Attribute value.
   */
  public String getCountry() {
    return this.country;
  }

  /**
   * Attribute 'country'.
   * @param pValue Attribute value.
   */
  public void setCountry(String pValue) {
    this.country = pValue;
  }

  /**
   * Attribute 'salesRepEmployeeNumber'.
   * @return Attribute value.
   */
  public int getSalesRepEmployeeNumber() {
    return this.salesRepEmployeeNumber!=null ? this.salesRepEmployeeNumber : 0;
  }

  /**
   * Attribute 'salesRepEmployeeNumber'.
   * @param pValue Attribute value.
   */
  public void setSalesRepEmployeeNumber(int pValue) {
    this.salesRepEmployeeNumber = pValue;
  }

  /**
   * Attribute 'creditLimit'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public double getCreditLimit() {
    return this.creditLimit!=null ? this.creditLimit : 0d;
  }

  /**
   * Attribute 'creditLimit'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setCreditLimit(double pValue) {
    this.creditLimit = pValue;
  }

  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Customer)) {
      return false;
    }
    if (getCustomerNumber() == 0) {
      return this == pOther;
    }
    return getCustomerNumber() == ((Customer)pOther).getCustomerNumber();
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getCustomerNumber();
    return result;
  }

}
