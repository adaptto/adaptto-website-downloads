package org.adaptto.slingrdbms.entities;

import java.lang.annotation.Annotation;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.spi.PersistenceProvider;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.hibernate.ejb.packaging.NamedInputStream;
import org.hibernate.ejb.packaging.Scanner;
import org.osgi.service.component.ComponentContext;

import com.day.commons.datasource.poolservice.DataSourceNotFoundException;
import com.day.commons.datasource.poolservice.DataSourcePool;

/**
 * Provides JPA entity manager
 *
 * TODO: this should be moved to a separate/generic bundle as a interface/abstract implementation.
 *   Thus the resource provider implementation needs no dependency to the project-specific entities bundle.
 */
@Component(
    metatype=true,
    label="adaptto Sling&RDBMS Entity Manager Provider",
    description="Provides JPA entity manager"
)
@Service(EntityManagerProvider.class)
public class EntityManagerProvider {

  @Reference
  PersistenceProvider mPersistenceProvider;

  @Reference
  DataSourcePool mDataSourcePool;

  /**
   * Property for datasource name
   */
  @Property(
      label="Datasource",
      description="Datasource name",
      value="slingrdbms_datasource"
  )
  public static final String PROPERTY_DATASOURCE_NAME = "datasource.name";

  private String mDatasourceName;
  EntityManagerFactory mEntityManagerFactory;

  @Activate
  protected synchronized void activate(ComponentContext pComponentContext) {
    // initialize db connection and JPA entitymanager
    Map<String,Object> props = new HashMap<String,Object>();
    try {
      mDatasourceName = (String)pComponentContext.getProperties().get(PROPERTY_DATASOURCE_NAME);
      props.put("hibernate.connection.datasource", mDataSourcePool.getDataSource(mDatasourceName));
    }
    catch (DataSourceNotFoundException ex) {
      throw new RuntimeException(ex);
    }
    ClassLoader oldContextClassloader = Thread.currentThread().getContextClassLoader();
    Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
    try {
      mEntityManagerFactory = mPersistenceProvider.createEntityManagerFactory("slingrdbms", props);
    }
    finally {
      Thread.currentThread().setContextClassLoader(oldContextClassloader);
    }
  }

  @Deactivate
  protected synchronized void deactivate(ComponentContext pComponentContext) {
    if (mEntityManagerFactory!=null) {
      mEntityManagerFactory.close();
    }
  }

  /**
   * @return Data source name
   */
  public String getDatasourceName() {
    return mDatasourceName;
  }

  /**
   * @return Entity manager instance
   */
  public EntityManager createEntityManager() {
    return mEntityManagerFactory.createEntityManager();
  }


  /**
   * {@link Scanner} implementation that does nothing - it is used to prevent hibernate
   * using it'S NativeScanner which does not work in OSGi environment.
   */
  public static class NopScanner implements Scanner {

    @Override
    public Set<Package> getPackagesInJar(URL pJartoScan, Set<Class<? extends Annotation>> pAnnotationsToLookFor) {
      return new HashSet<Package>();
    }

    @Override
    public Set<Class<?>> getClassesInJar(URL pJartoScan, Set<Class<? extends Annotation>> pAnnotationsToLookFor) {
      return new HashSet<Class<?>>();
    }

    @Override
    public Set<NamedInputStream> getFilesInJar(URL pJartoScan, Set<String> pFilePatterns) {
      return new HashSet<NamedInputStream>();
    }

    @Override
    public Set<NamedInputStream> getFilesInClasspath(Set<String> pFilePatterns) {
      return new HashSet<NamedInputStream>();
    }

    @Override
    public String getUnqualifiedJarName(URL pJarUrl) {
      return null;
    }

  }

}
