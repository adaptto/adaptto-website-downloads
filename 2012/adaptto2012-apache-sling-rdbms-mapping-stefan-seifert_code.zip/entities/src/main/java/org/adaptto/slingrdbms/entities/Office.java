package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity 'Offices'
 */
@Entity
@Table(name = "Offices")
public class Office implements java.io.Serializable {
  private static final long serialVersionUID = 1794781360L;

  @Id
  @Column(name = "officeCode", length=10, nullable=false)
  private String officeCode = "";

  @Column(name = "city", length=50, nullable=false)
  private String city = "";

  @Column(name = "phone", length=50)
  private String phone = "";

  @Column(name = "addressLine1", length=50)
  private String addressLine1 = "";

  @Column(name = "addressLine2", length=50)
  private String addressLine2 = "";

  @Column(name = "state", length=50)
  private String state = "";

  @Column(name = "country", length=50)
  private String country = "";

  @Column(name = "postalCode", length=15)
  private String postalCode = "";

  @Column(name = "territory", length=10)
  private String territory = "";


  /**
   * Initializes a new <code>Offices</code> object.
   */
  public Office() {
    // empty constructor
  }

  /**
   * Attribute 'officeCode'. Required.
   * @return Attribute value.
   */
  public String getOfficeCode() {
    return this.officeCode;
  }

  /**
   * Attribute 'officeCode'. Required.
   * @param pValue Attribute value.
   */
  public void setOfficeCode(String pValue) {
    this.officeCode = pValue;
  }

  /**
   * Attribute 'city'.
   * @return Attribute value.
   */
  public String getCity() {
    return this.city;
  }

  /**
   * Attribute 'city'.
   * @param pValue Attribute value.
   */
  public void setCity(String pValue) {
    this.city = pValue;
  }

  /**
   * Attribute 'phone'.
   * @return Attribute value.
   */
  public String getPhone() {
    return this.phone;
  }

  /**
   * Attribute 'phone'.
   * @param pValue Attribute value.
   */
  public void setPhone(String pValue) {
    this.phone = pValue;
  }

  /**
   * Attribute 'addressLine1'.
   * @return Attribute value.
   */
  public String getAddressLine1() {
    return this.addressLine1;
  }

  /**
   * Attribute 'addressLine1'.
   * @param pValue Attribute value.
   */
  public void setAddressLine1(String pValue) {
    this.addressLine1 = pValue;
  }

  /**
   * Attribute 'addressLine2'.
   * @return Attribute value.
   */
  public String getAddressLine2() {
    return this.addressLine2;
  }

  /**
   * Attribute 'addressLine2'.
   * @param pValue Attribute value.
   */
  public void setAddressLine2(String pValue) {
    this.addressLine2 = pValue;
  }

  /**
   * Will represent states in US, provinces in Canada, areas in the UK etc.
   * @return Attribute value.
   */
  public String getState() {
    return this.state;
  }

  /**
   * Will represent states in US, provinces in Canada, areas in the UK etc.
   * @param pValue Attribute value.
   */
  public void setState(String pValue) {
    this.state = pValue;
  }

  /**
   * Attribute 'country'.
   * @return Attribute value.
   */
  public String getCountry() {
    return this.country;
  }

  /**
   * Attribute 'country'.
   * @param pValue Attribute value.
   */
  public void setCountry(String pValue) {
    this.country = pValue;
  }

  /**
   * Attribute 'postalCode'.
   * @return Attribute value.
   */
  public String getPostalCode() {
    return this.postalCode;
  }

  /**
   * Attribute 'postalCode'.
   * @param pValue Attribute value.
   */
  public void setPostalCode(String pValue) {
    this.postalCode = pValue;
  }

  /**
   * APAC, EMEA, NA etc.
   * @return Attribute value.
   */
  public String getTerritory() {
    return this.territory;
  }

  /**
   * APAC, EMEA, NA etc.
   * @param pValue Attribute value.
   */
  public void setTerritory(String pValue) {
    this.territory = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof Office)) {
      return false;
    }
    if (getOfficeCode() == null) {
      return this == pOther;
    }
    return getOfficeCode().equals(((Office)pOther).getOfficeCode());
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getOfficeCode().hashCode();
    return result;
  }

}
