package org.adaptto.slingrdbms.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entity 'OrderDetails'
 */
@Entity
@Table(name = "OrderDetails")
public class OrderDetail implements java.io.Serializable {
  private static final long serialVersionUID = -2663683L;

  @Id
  @ManyToOne(fetch=FetchType.LAZY, optional=false)
  @JoinColumn(name = "orderNumber", nullable=false)
  private Order orderNumber = null;

  @Id
  @ManyToOne(fetch=FetchType.LAZY, optional=true)
  @JoinColumn(name = "productCode", nullable=false)
  private Product productCode = null;

  @Column(name = "quantityOrdered")
  private Integer quantityOrdered = 0;

  @Column(name = "priceEach")
  private Double priceEach = 0d;

  @Column(name = "orderLineNumber")
  private Integer orderLineNumber = 0;



  /**
   * Initializes a new <code>OrderDetails</code> object.
   */
  public OrderDetail() {
    // empty constructor
  }

  /**
   * Attribute 'orderNumber'. Required.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public Order getOrderNumber() {
    return this.orderNumber;
  }

  /**
   * Attribute 'orderNumber'. Required.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setOrderNumber(Order pValue) {
    this.orderNumber = pValue;
  }

  /**
   * Attribute 'productCode'.
   * @return Attribute value.
   */
  public Product getProductCode() {
    return this.productCode;
  }

  /**
   * Attribute 'productCode'.
   * @param pValue Attribute value.
   */
  public void setProductCode(Product pValue) {
    this.productCode = pValue;
  }

  /**
   * Attribute 'quantityOrdered'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public int getQuantityOrdered() {
    return this.quantityOrdered!=null ? this.quantityOrdered : 0;
  }

  /**
   * Attribute 'quantityOrdered'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setQuantityOrdered(int pValue) {
    this.quantityOrdered = pValue;
  }

  /**
   * Attribute 'priceEach'.<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public double getPriceEach() {
    return this.priceEach!=null ? this.priceEach : 0d;
  }

  /**
   * Attribute 'priceEach'.<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setPriceEach(double pValue) {
    this.priceEach = pValue;
  }

  /**
   * Used to sort the products associated with a given order<br>
   * Default value for new objects: <b>0</b>
   * @return Attribute value.
   */
  public int getOrderLineNumber() {
    return this.orderLineNumber!=null ? this.orderLineNumber : 0;
  }

  /**
   * Used to sort the products associated with a given order<br>
   * Default value for new objects: <b>0</b>
   * @param pValue Attribute value.
   */
  public void setOrderLineNumber(int pValue) {
    this.orderLineNumber = pValue;
  }


  /**
   * Checks equality for two entities.
   * Entities of same type are compared using their primery keys.
   * If the entity is not saved yet, the comparison is done by checking for object identity.
   * @param pOther Other object
   * @return true if entities are equal
   */
  @Override
  public boolean equals(Object pOther) {
    if (pOther == null || !(pOther instanceof OrderDetail)) {
      return false;
    }
    if (getOrderNumber()==null || getProductCode()==null) {
      return this == pOther;
    }
    return getOrderNumber().equals(((OrderDetail)pOther).getOrderNumber())
        && getProductCode().equals(((OrderDetail)pOther).getProductCode());
  }

  /**
   * Generate hashcode for entity.
   * Uses combination of class name hashcode and primary key to construct hascode value.
   * Please note: Hashcode will change if a newly created object is saved first time in database.
   * @return hashcode
   */
  @Override
  public int hashCode() {
    int result = 17;
    result = 37*result + getClass().hashCode();
    result = 37*result + getOrderNumber().hashCode();
    result = 37*result + getProductCode().hashCode();
    return result;
  }

}
