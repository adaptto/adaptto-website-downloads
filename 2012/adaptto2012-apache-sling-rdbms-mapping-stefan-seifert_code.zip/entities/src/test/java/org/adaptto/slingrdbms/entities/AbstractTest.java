package org.adaptto.slingrdbms.entities;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;

import org.junit.After;
import org.junit.Before;

/**
 * Basic testcase that provides support for a custom entity manager.
 */
public abstract class AbstractTest {

  @PersistenceUnit
  private EntityManagerFactory mEntityManagerFactory;

  private EntityManager mEntityManager = null;
  private EntityTransaction mTransaction = null;

  /**
   * Set up entity manager
   */
  @Before
  public void setUp() {

    // initialize db connection and JPA entitymanager
    Map<String,String> props = new HashMap<String,String>();
    props.put("hibernate.connection.username", "root");
    props.put("hibernate.connection.password", "root");
    props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
    props.put("hibernate.connection.url", "jdbc:mysql://localhost/birt?characterEncoding=utf8&useUnicode=true");
    props.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
    props.put("hibernate.show_sql", "false");
    mEntityManagerFactory = Persistence.createEntityManagerFactory("slingrdbms", props);

    // get new entity manager
    mEntityManager = mEntityManagerFactory.createEntityManager();

    // start transaction
    startTransaction();
  }

  /**
   * Tear down entity manager
   */
  @After
  public void tearDown() {
    // rollback transaction
    if (mTransaction!=null) {
      try {
        mTransaction.rollback();
      }
      catch (Exception ex) {
        // ignore
      }
      mTransaction = null;
    }

    if (mEntityManager!=null) {
      mEntityManager.close();
      mEntityManager = null;
    }
  }

  /**
   * Get entity manager factory.
   * @return Entity manager factory.
   */
  public EntityManagerFactory getEntityManagerFactory() {
    return mEntityManagerFactory;
  }

  /**
   * Get entity manager instance
   * @return Entity manager instance
   */
  public EntityManager getEntityManager() {
    return mEntityManager;
  }

  /**
   * Start transaction.
   */
  public void startTransaction() {
    mTransaction = mEntityManager.getTransaction();
    mTransaction.begin();
  }

  /**
   * Commit transaction
   */
  public void commitTransaction() {
    mTransaction.commit();
    mTransaction = null;
  }

  /**
   * Rollback transaction
   */
  public void rollbackTransaction() {
    mTransaction.rollback();
    mTransaction = null;
  }

}
