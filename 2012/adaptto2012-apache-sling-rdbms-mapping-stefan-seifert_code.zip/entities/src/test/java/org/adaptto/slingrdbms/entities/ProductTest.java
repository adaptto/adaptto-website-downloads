package org.adaptto.slingrdbms.entities;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit Test
 */
public class ProductTest extends AbstractTest {

  /**
   * Simple database access test
   * @throws Exception
   */
  @Test
  public void testFindExisting() throws Exception {

    Product product = getEntityManager().find(Product.class, "S18_1662");
    Assert.assertNotNull("product exists", product);
    Assert.assertEquals("product name", "1980s Black Hawk Helicopter", product.getProductName());

  }

  /**
   * Simple database access test
   * @throws Exception
   */
  @Test
  public void testCreateNew() throws Exception {

    // test create
    Product product = new Product();
    product.setProductCode("abc");
    product.setProductName("The ABC");
    getEntityManager().persist(product);
    getEntityManager().flush();

    // test read
    Product product2 = getEntityManager().find(Product.class, "abc");
    Assert.assertNotNull("product exists", product2);
    Assert.assertEquals("product name", "The ABC", product2.getProductName());

    // test remove
    getEntityManager().remove(product2);
    getEntityManager().flush();
    Assert.assertNull(getEntityManager().find(Product.class, "abc"));

  }

}
