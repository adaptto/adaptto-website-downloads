package com.adobe.training.jackrabbit.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.jcr.*;

import org.apache.jackrabbit.commons.JcrUtils;

/**
 * The basic Main class with the boilerplate code to create a repostiory and open a session. The extending class should implement the doWork method, which has a
 * valid repository and session Objects at its disposal.
 * @author isechyn
 */
public abstract class Main {

  protected Repository repository;
  protected Session session;
  protected Credentials defautlCredentials = new SimpleCredentials("admin", "admin".toCharArray());

  /**
   * Default constructor
   */
  public Main() {

  }

  /**
   * Creates a remote repository and opens a new session. The "content" node will be deleted, providing a blank repository for each execution.
   * @throws LoginException
   * @throws RepositoryException
   * @throws IOException
   */
  protected void setup(String[] args) throws LoginException, RepositoryException, IOException {
    this.repository = JcrUtils.getRepository("http://localhost:4512/crx/server");
    this.session = this.repository.login(defautlCredentials);
  }

  /**
   * Logs out the current session. TransientRepository takes care of the rest.
   * @throws RepositoryException
   * @throws PathNotFoundException
   */
  private void tearDown() throws RepositoryException {
    this.session.save();
    this.session.logout();
  }

  /**
   * This method may contain all operations on the repository
   * @throws RepositoryException
   */
  public abstract void doWork() throws RepositoryException;

  /**
   * The main run method called, when executing the class
   */
  protected void run(String[] args) {
    try {
      this.setup(args);

      this.doWork();

      try {
        // sleep a while to align output
        Thread.sleep(1000);
      }
      catch (InterruptedException ex) {}
      InputStreamReader inp = new InputStreamReader(System.in);
      BufferedReader br = new BufferedReader(inp);
      System.out.println("Enter any character to stop the application : ");
      br.readLine();
      this.tearDown();
      System.out.println("Stopped.");
    }
    catch (LoginException e) {
      e.printStackTrace();
    }
    catch (RepositoryException e) {
      e.printStackTrace();
    }
    catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  /**
   * Prints the properties of the passed node
   * @param node
   * @throws RepositoryException
   * @throws ValueFormatException
   */
  static protected void dumpProperties(Node node) throws RepositoryException, ValueFormatException {
    System.out.println("Node " + node.getPath() + " has following properties:");
    PropertyIterator propertyIterator = node.getProperties();
    while (propertyIterator.hasNext()) {
      Property property = propertyIterator.nextProperty();
      if (property.getDefinition().isMultiple()) {
        // A multi-valued property, print all values
        Value[] values = property.getValues();
        for (int i = 0; i < values.length; i++) {
          System.out.println(property.getPath() + " = " + values[i].getString());
        }
      }
      else {
        // A single-valued property
        System.out.println(property.getPath() + " = " + property.getString());
      }
    }
  }

  static protected void copyProperties(Node src, Node target) throws RepositoryException {
    // NOTE: you cannot copy protected properties like "jcr:mixinTypes" (exception "javax.jcr.nodetype.ConstraintViolationException: Item is protected")
    PropertyIterator propertyIterator = src.getProperties();
    while (propertyIterator.hasNext()) {
      Property property = propertyIterator.nextProperty();
      System.out.println("will copy '" + property.getName() + "'");
      if (property.getDefinition().isMultiple()) {
        target.setProperty(property.getName(), property.getValues());
      }
      else {
        target.setProperty(property.getName(), property.getValue());
      }
    }
  }

}
