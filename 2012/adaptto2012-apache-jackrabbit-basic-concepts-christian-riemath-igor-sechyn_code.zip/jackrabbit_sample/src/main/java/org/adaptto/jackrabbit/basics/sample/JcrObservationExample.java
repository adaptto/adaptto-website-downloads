package org.adaptto.jackrabbit.basics.sample;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.jcr.LoginException;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.nodetype.NodeType;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.EventListener;
import javax.jcr.observation.ObservationManager;

import org.apache.jackrabbit.commons.JcrUtils;
import com.adobe.training.jackrabbit.main.Main;

/**
 * Observation/References example
 */
public class JcrObservationExample extends Main implements EventListener {

    ObservationManager obsManager;

    String observationRootPath = "/content/blog/articles/2012/09/jackrabbitArticle/comments";

    String inboxPath = "/content/blog/admin/newComments";

    final String PN_REFS = "refs";

    /**
     * @throws LoginException
     * @throws RepositoryException
     * @throws IOException
     */
    @Override
    protected void setup(String[] args) throws LoginException, RepositoryException, IOException {
        super.setup(args);
        obsManager = session.getWorkspace().getObservationManager();
        obsManager.addEventListener(this, (Event.NODE_ADDED | Event.PROPERTY_CHANGED), observationRootPath, true, null,
                null, false);
    }

    @Override
    public void doWork() throws RepositoryException {
        Node commentsRoot = session.getNode(observationRootPath);
        Node newComment = commentsRoot.addNode("comment_" + new SimpleDateFormat("HH-mm-ss").format(new Date()));
        // newComment.addMixin("mix:shareable"); // does not work with jcr2spi, see note below.
        newComment.addMixin(NodeType.MIX_REFERENCEABLE);
        newComment.setProperty("text", "Fantastic!");
        newComment.setProperty("author", "Karin Khan");
        session.save();
    }

    @Override
    public void onEvent(EventIterator events) {
        try {
            while (events.hasNext()) {
                Event event = events.nextEvent();
                if (event.getType() == Event.NODE_ADDED) {
                    Node newComment = session.getNode(event.getPath());
                    System.out.println("a new comment was added: " + newComment.getPath() + " - will notify the admin");

                    // NOTE: The following is not allowed with org.apache.jackrabbit.jcr2spi.WorkspaceImpl,
                    // so we cannot deal with shareable nodes here.
                    // Workspace workspace = session.getWorkspace();
                    // workspace.clone(workspace.getName(), newComment.getPath(), inboxPath + "/" +
                    // newComment.getName(), false);

                    Node inbox = JcrUtils.getOrCreateByPath(inboxPath, "nt:unstructured", session);

                    // add new comment to existing references in the inbox
                    boolean weak = true;
                    Value newCommentValue = session.getValueFactory().createValue(newComment, weak);
                    Value[] oldRefs = (inbox.hasProperty(PN_REFS)) ? inbox.getProperty(PN_REFS).getValues()
                            : new Value[] {};
                    List<Value> newRefs = new ArrayList<Value>(Arrays.asList(oldRefs));
                    newRefs.add(newCommentValue);
                    inbox.setProperty(PN_REFS, newRefs.toArray(new Value[] {}));
                }
            }
            // session.save(); // would freeze
        } catch (RepositoryException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        new JcrObservationExample().run(args);
    }

}
