package org.adaptto.jackrabbit.basics.sample;

import java.util.Iterator;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.ValueFormatException;

import com.adobe.training.jackrabbit.main.Main;

/**
 * JcrBasicsExample
 */
public class JcrBasicsExample extends Main {

  @SuppressWarnings("unchecked")
  @Override
  public void doWork() throws RepositoryException {
    try {
      Node blog = session.getNode("/content/blog/articles/2012/09");
      Iterator<Node> articles = blog.getNodes();
      while (articles.hasNext()) {
        Node article = articles.next();
        System.out.println("******************************* BLOG START*****************************");
        System.out.println("Title: " + article.getProperty("title").getString());
        System.out.println("Author: " + article.getProperty("author").getString());
        System.out.println("Text: " + article.getProperty("text").getString());
        printComments(article);
        System.out.println("******************************* BLOG END*****************************");
        System.out.println();
        System.out.println();
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private void printComments(Node article) {
    try {
      System.out.println("******************************* Comments *****************************");
      Node commentsNode = article.getNode("comments");
      printThread(commentsNode, 0);
      System.out.println("******************************* Comments *****************************");
    }
    catch (RepositoryException ex) {
      ex.printStackTrace();
    }

  }

  private void printThread(Node commentsNode, int level) throws RepositoryException, ValueFormatException, PathNotFoundException {
    NodeIterator comments = commentsNode.getNodes();
    while (comments.hasNext()) {
      Node comment = comments.nextNode();
      String indent = getIndent(level);
      System.out.println(indent + "Author: " + comment.getProperty("author").getString());
      System.out.println(indent + "Comment: " + comment.getProperty("text").getString());
      System.out.println();
      printThread(comment, level + 1);
    }
  }

  private String getIndent(int level) {
    StringBuilder indent = new StringBuilder();
    for (int i = 0; i < level; i++) {
    	indent.append("\t");
    }
    return indent.toString();
  }

  /**
   * The main method
   * @param args
   */
  public static void main(String[] args) {
    new JcrBasicsExample().run(args);
  }

}
