.apdaptTo() Sling CXF Integration Sample Application
====================================================

Requirements: JDK 1.6, Maven 2 or 3

To run the example:

1. Checkout current Sling from trunk and build it


2. Start launchpad builder e.g. with

java -jar target/org.apache.sling.launchpad-7-SNAPSHOT-standalone.jar -c sling -f -


3. Build and deploy sample application bundles into OSGI container using:

mvn install sling:install

(assumes sling is running on localhost:8080)


4. Launch SoapUI Mock Service
- Download and launch SoapUI 4.0
- Open SoapUI project soapui/helloworld-soapui-project.xml
- Open "helloworld/Greeter_SOAPBinding MockService"
- Start Mock Service using the "play" button


5. Open Sample Application in Browser
- URL: http://localhost:8080/slingcxf.html


6. Test SOAP Client Access
- URL: http://localhost:8080/slingcxf/client.html
- Calls SOAP method from SoapUI mock service and displays the answer


7. Test SOAP Server
- Open Request "helloworld/Greeter_SOAPBinding/greetMe/Request 1" in SoapUI
- Execute method using the "play button"
- The SOAP method of the sling application is called and the answer displayed as SOAP response



---------------------------------------------------------
�2011 pro!vision GmbH            http://www.pro-vision.de
