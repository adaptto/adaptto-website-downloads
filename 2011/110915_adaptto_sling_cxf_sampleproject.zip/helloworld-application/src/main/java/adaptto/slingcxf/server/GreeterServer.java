//$URL: http://feanor:8050/svn/test/trunk/DevTest/apache-sling/adaptto/sling-cxf-integration/helloworld-application/src/main/java/adaptto/slingcxf/server/GreeterServer.java $
//$Id: GreeterServer.java 680 2011-09-12 16:57:25Z PRO-VISION\SSeifert $
package adaptto.slingcxf.server;

import org.apache.commons.lang.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.hello_world_soap_http.Greeter;
import org.apache.hello_world_soap_http.PingMeFault;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;
import adaptto.slingcxf.server.util.AbstractJaxWsServer;

/**
 * Implementation for {@link Greeter} SOAP service.
 */
@SlingServlet(
    resourceTypes = "/apps/slingcxf/components/server",
    extensions = AbstractJaxWsServer.SOAP_EXTENSION,
    methods = { "GET", "POST" }
)
public class GreeterServer extends AbstractJaxWsServer implements Greeter {
    private static final long serialVersionUID = 1L;

    @Override
    protected Class getServerInterfaceType() {
        return Greeter.class;
    }

    @Override
    public void pingMe() throws PingMeFault {
        // nothing to do
    }

    @Override
    public String sayHi() {
        return "Hi!";
    }

    @Override
    public void greetMeOneWay(String requestType) {
        // nothing to do
    }

    @Override
    public String greetMe(String name) {
        // get pattern for greeting response from JCR
        Resource resource = getCurrentRequest().getResource();
        ValueMap properties = resource.adaptTo(ValueMap.class);
        String greetResponsePattern = properties.get("greetResponsePattern", "Hello ${name}!");
        
        // replace placeholder with the client's name
        return StringUtils.replace(greetResponsePattern, "${name}", name);
    }

}
