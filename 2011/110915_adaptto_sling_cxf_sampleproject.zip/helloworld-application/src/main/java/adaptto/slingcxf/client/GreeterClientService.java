package adaptto.slingcxf.client;

import java.util.Map;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.hello_world_soap_http.Greeter;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import adaptto.slingcxf.client.util.JaxWsClientFactory;


/**
 * Service for configuring SOAP proxy client instance
 */
@Component(metatype=true, label="slingcxf Greeter Client Service")
@Service(GreeterClientService.class)
public class GreeterClientService {

    @Property(label="Greeter Webservice URL", value=GreeterClientService.DEFAULT_PORTURL)
    private static final String PROPERTY_PORTURL = "portUrl";
    private static final String DEFAULT_PORTURL = "http://localhost:8088/mockGreeter_SOAPBinding";
    
    private final Logger log = LoggerFactory.getLogger(getClass());
    
    private String portUrl;
    private Greeter greeterInstance;
    
    @Activate
    protected final void activate(final Map<String, String> config) { 
        try {
        
            // get port url from OSGI config
            this.portUrl = PropertiesUtil.toString(config.get(PROPERTY_PORTURL), DEFAULT_PORTURL);
            log.info("portUrl=" + this.portUrl);
            
            // instantiate greeter SOAP client proxy
            this.greeterInstance = JaxWsClientFactory.create(Greeter.class, this.portUrl);
            
        }
        catch (RuntimeException ex) {
            log.error("Unable to instanciate SOAP service proxy client.", ex);
        }
    }
    
    /**
     * @return Greeter SOAP client proxy instance
     */
    public Greeter getInstance() {
        return this.greeterInstance;
    }
    
    /**
     * @return Configured port url
     */
    public String getPortUrl() {
        return this.portUrl;
    }

}
