(function($){
    var isContentFinderWindow = window.document.location.href.indexOf("/cf#/") > -1;
    if (isContentFinderWindow) {
        return;
    }

    if (typeof window.console == "undefined") {
        window.console = { debug: function() {}};
    }

    var CHANNEL = CQ.WCM.getPagePath();
    var USER = CQ.User.getUserName();

    var doRefresh = false;
    var SYNC_LISTENERS = {
        editing: function() {
            console.debug("editing", this.path);
            $.comet.publish(CHANNEL, {
                from: USER,
                action: "editing",
                path: this.path
            });
            return true;
        },
        refresh: function() {
            doRefresh = true;
            return true;
        },
        remove: function() {
            console.debug("remove", this.path);
            $.comet.publish(CHANNEL, {
                from: USER,
                action: "remove",
                path: this.path
            });
            return true;
        },
        cancel: function() {
            var action = doRefresh ? "refresh" : "cancel";
            doRefresh = false;
            console.debug(action, this.path);
            $.comet.publish(CHANNEL, {
                from: USER,
                action: action,
                path: this.path
            });
            return true;
        }
    };

    CQ.WCM.on("editablesready", function() {
        var editables = CQ.WCM.getEditables();
        console.debug("init editable listeners", editables);
        for (var e in editables) {
            var editable = editables[e];
            if (editable) {
                var dialog = editable.dialog && editable.getEditDialog();
                if (dialog) {
                    dialog.addListener("beforesubmit", SYNC_LISTENERS.refresh);
                    dialog.addListener("hide", SYNC_LISTENERS.cancel);
                }
            }
            editable.addListener("beforeedit", SYNC_LISTENERS.editing);
            editable.addListener("afterdelete", SYNC_LISTENERS.remove);
        }
    });

    var SYNC_ACTIONS = {
        join: function(data) {
            CQ.Notification.notify("Notification", data.from + " opened the same page.");
            $.comet.publish(CHANNEL, {
                from: USER,
                action: "present"
            });
        },
        present: function(data) {
            CQ.Notification.notify("Notification", data.from + " is on the same page.");
        },
        leave: function(data) {
            CQ.Notification.notify("Notification", data.from + " left the page.");
        },
        editing: function(data) {
            var editable = CQ.WCM.getEditable(data.path);
            if (editable) {
                editable.el.addClass("editing");
            }
        },
        refresh: function(data) {
            var editable = CQ.WCM.getEditable(data.path);
            if (editable) {
                editable.el.removeClass("editing");
                setTimeout(function() {
                    editable.refresh();
                }, 200);
            }
        },
        cancel: function(data) {
            var editable = CQ.WCM.getEditable(data.path);
            if (editable) {
                editable.el.removeClass("editing");
            }
        },
        remove: function(data) {
            var editable = CQ.WCM.getEditable(data.path);
            if (editable) {
                editable.el.removeClass("editing");
                editable.remove();
            }
        }
    };

    $(window).load(function() {
        // async to avoid loading indicator in browsers
        setTimeout(function() {
            $.comet.init("http://" + location.host + "/system/cometd");
            $.comet.startBatch();
            $.comet.subscribe(CHANNEL, function(msg) {
                if (msg.data && msg.data.action && msg.data.from != USER) {
                    if (typeof SYNC_ACTIONS[msg.data.action] == "function") {
                        SYNC_ACTIONS[msg.data.action](msg.data);
                    }
                }

                console.debug("RECV:", msg.data.from, msg.data.action, msg.data.path);
            });
            $.comet.publish(CHANNEL, {
                from: USER,
                action: "join"
            });
            $.comet.endBatch();
        }, 1);
    });

    $(window).unload(function() {
        console.debug("unload window");
        $.comet.startBatch();
        $.comet.publish(CHANNEL, {
            from: USER,
            action: "leave"
        });
        $.comet.unsubscribe(CHANNEL);
        $.comet.endBatch();
        $.comet.disconnect();
    });
})($);