//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/components/LikeMe.java $
//$Id: LikeMe.java 22798 2013-09-18 21:31:07Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.components;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ModifiableValueMap;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;

/**
 * Like update action using Sling CRUD API to write to JCR
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/talk", selectors="likeme", methods="POST")
public class LikeMe extends SlingAllMethodsServlet {
  private static final long serialVersionUID = -827047552677135151L;

  @Override
  protected void doPost(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {

    updateLikeCounter(pRequest);

    // return to main view
    pResponse.sendRedirect(pRequest.getResource().getPath() + ".html");
  }

  private void updateLikeCounter(SlingHttpServletRequest pRequest) throws PersistenceException {

    ValueMap props = ResourceUtil.getValueMap(pRequest.getResource());

    // check if a user with this ip address has already liked this
    String ipAddress = pRequest.getRemoteAddr();
    String[] likedAddresses = props.get("likedAddresses", new String[0]);
    if (ArrayUtils.contains(likedAddresses, ipAddress)) {
      return;
    }

    // increment like counter and store ip address
    ValueMap writeProps = pRequest.getResource().adaptTo(ModifiableValueMap.class);
    writeProps.put("likes", writeProps.get("likes", 0L) + 1);

    List<String> updatedLikedAddresses = new ArrayList<>(Arrays.asList(likedAddresses));
    updatedLikedAddresses.add(ipAddress);
    writeProps.put("likedAddresses", updatedLikedAddresses.toArray());

    // save to repository
    pRequest.getResourceResolver().commit();

  }

}
