//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/jcrdemo/JcrQuerySample.java $
//$Id: JcrQuerySample.java 22798 2013-09-18 21:31:07Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.jcrdemo;

import java.io.IOException;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.query.Query;
import javax.jcr.query.QueryManager;
import javax.jcr.query.QueryResult;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * JCR query example
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/index", selectors="jcrquerysample")
@SuppressWarnings("deprecation")
public class JcrQuerySample extends SlingSafeMethodsServlet {
  private static final long serialVersionUID = -8909492203133496844L;

  @Override
  protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {

    Session session = pRequest.getResourceResolver().adaptTo(Session.class);

    try {
      String jcrContent = queryJcrContent(session);
      pResponse.setContentType("text/plain;charset=UTF-8");
      pResponse.getWriter().write(jcrContent);
    }
    catch (RepositoryException ex) {
      throw new ServletException(ex);
    }
  }

  String queryJcrContent(Session pSession) throws RepositoryException {

    // get query manager
    QueryManager queryManager = pSession.getWorkspace().getQueryManager();

    // query for all nodes with tag "JCR"
    Query query = queryManager.createQuery("/jcr:root/content/adaptto//*[tags='JCR']", Query.XPATH);

    // iterate over results
    QueryResult result = query.execute();
    NodeIterator nodes = result.getNodes();
    StringBuilder output = new StringBuilder();
    while (nodes.hasNext()) {
      Node node = nodes.nextNode();
      output.append("path=" + node.getPath() + "\n");
    }

    return output.toString();
  }

}
