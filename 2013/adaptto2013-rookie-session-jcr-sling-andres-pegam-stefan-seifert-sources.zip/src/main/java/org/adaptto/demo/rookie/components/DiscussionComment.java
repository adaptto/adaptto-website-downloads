//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/components/DiscussionComment.java $
//$Id: DiscussionComment.java 22844 2013-09-21 23:34:02Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.components;

import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.util.Date;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * Servlet example comment for social comment entry
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/social/comment")
public class DiscussionComment extends SlingSafeMethodsServlet {
  private static final long serialVersionUID = -6549518176129073294L;

  @Override
  protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {
    Writer out = pResponse.getWriter();

    // read properties via Sling API
    ValueMap props = ResourceUtil.getValueMap(pRequest.getResource());
    String author = props.get("author", "Anonymous");
    Date created = props.get("jcr:created", Date.class);
    String text = props.get("text", "");

    // output comment as HTML
    out.write("<p>");
    out.write("<em>" + StringEscapeUtils.escapeHtml4(author)
        + " (" + DateFormat.getDateTimeInstance().format(created) + ")</em><br/>");
    out.write(StringEscapeUtils.escapeHtml4(text));
    out.write("</p>");

  }

}
