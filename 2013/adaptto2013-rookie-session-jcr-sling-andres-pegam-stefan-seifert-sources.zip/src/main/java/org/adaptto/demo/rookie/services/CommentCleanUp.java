//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/services/CommentCleanUp.java $
//$Id: CommentCleanUp.java 22799 2013-09-18 22:03:20Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.services;

import java.util.Iterator;

import javax.jcr.query.Query;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.resource.LoginException;
import org.apache.sling.api.resource.PersistenceException;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.api.resource.ValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Background job to automatically remove empty comments.
 */
@Component(immediate = true, metatype = true, label = "adaptTo() Rookie Demo Comment Cleanup Service",
    description = "Removes all empty comments.")
@Service(value = Runnable.class)
public class CommentCleanUp implements Runnable {

  @SuppressWarnings("unused")
  @Property(value = "0 0/15 * * * ?", // run every 15 minutes
  label = "Scheduler Expression",
      description = "Cron expression for scheduling, see http://www.quartz-scheduler.org/docs/tutorials/crontrigger.html for examples.")
  private static final String PROPERTY_CRON_EXPRESSION = "scheduler.expression";

  @Reference
  ResourceResolverFactory mResourceResolverFactory;

  private final Logger mLog = LoggerFactory.getLogger(getClass());

  @Override
  public void run() {
    ResourceResolver adminResolver = null;
    try {

      // get administrative resolver
      adminResolver = mResourceResolverFactory.getAdministrativeResourceResolver(null);

      // fire query to get all comment nodes
      mLog.debug("Query for all comments.");
      Iterator<Resource> comments = adminResolver.findResources("SELECT * "
          + "FROM [sling:OrderedFolder] "
          + "WHERE ISDESCENDANTNODE([/content/adaptto]) "
          + "AND [sling:resourceType]='/apps/rookiedemo/components/social/comment'", Query.JCR_SQL2);

      // iterate over all comments and remove those that have empty text
      while (comments.hasNext()) {
        Resource comment = comments.next();
        mLog.debug("Check comment {}", comment.getPath());

        ValueMap props = ResourceUtil.getValueMap(comment);
        if (StringUtils.isEmpty(props.get("text", String.class))) {
          mLog.info("Delete empty comment {}", comment.getPath());
          adminResolver.delete(comment);
        }
      }

      // save changes to repository
      if (adminResolver.hasChanges()) {
        adminResolver.commit();
      }

    }
    catch (LoginException ex) {
      mLog.error("Error getting administrativ resolver.", ex);
    }
    catch (PersistenceException ex) {
      mLog.error("Error persisting changes to repository.", ex);
    }
    finally {
      if (adminResolver!=null) {
        adminResolver.close();
      }
    }
  }

}
