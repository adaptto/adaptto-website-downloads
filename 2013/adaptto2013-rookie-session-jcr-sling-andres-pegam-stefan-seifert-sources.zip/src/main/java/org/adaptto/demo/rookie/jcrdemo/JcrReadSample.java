//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/jcrdemo/JcrReadSample.java $
//$Id: JcrReadSample.java 22798 2013-09-18 21:31:07Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.jcrdemo;

import java.io.IOException;
import java.util.Arrays;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.Value;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * JCR read example
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/index", selectors="jcrreadsample")
public class JcrReadSample extends SlingSafeMethodsServlet {
  private static final long serialVersionUID = -2975383706747400409L;

  @Override
  protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {

    Session session = pRequest.getResourceResolver().adaptTo(Session.class);

    try {
      String jcrContent = readJcrContent(session);
      pResponse.setContentType("text/plain;charset=UTF-8");
      pResponse.getWriter().write(jcrContent);
    }
    catch (RepositoryException ex) {
      throw new ServletException(ex);
    }
  }

  String readJcrContent(Session pSession) throws RepositoryException {

    // get node directly
    Node day1 = pSession.getNode("/content/adaptto/2013/day1");

    // get first child node
    Node firstTalk = day1.getNodes().nextNode();

    // read property values
    String title = firstTalk.getProperty("jcr:title").getString();
    long duration = firstTalk.getProperty("durationMin").getLong();

    // read multi-valued property
    Value[] tagValues = firstTalk.getProperty("tags").getValues();
    String[] tags = new String[tagValues.length];
    for (int i=0; i<tagValues.length; i++) {
      tags[i] = tagValues[i].getString();
    }

    return "First talk: " + title + " (" + duration + " min)\n"
        + "Tags: " + Arrays.toString(tags) + "\n"
        + "Path: " + firstTalk.getPath();
  }

}
