//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/jcrdemo/JcrWriteSample.java $
//$Id: JcrWriteSample.java 22798 2013-09-18 21:31:07Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.jcrdemo;

import java.io.IOException;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.servlet.ServletException;

import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * JCR write example
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/index", selectors="jcrwritesample")
public class JcrWriteSample extends SlingSafeMethodsServlet {
  private static final long serialVersionUID = -3387175284108086362L;

  @Override
  protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {

    Session session = pRequest.getResourceResolver().adaptTo(Session.class);

    try {
      writeJcrContent(session);
      pResponse.sendRedirect(pRequest.getResource().getPath() + ".jcrreadsample.txt");
    }
    catch (RepositoryException ex) {
      throw new ServletException(ex);
    }
  }

  void writeJcrContent(Session pSession) throws RepositoryException {

    // get node directly
    Node talk = pSession.getNode("/content/adaptto/2013/day1/rookie-session");

    // write property values
    talk.setProperty("jcr:title", "My Rookie Session");
    talk.setProperty("durationMin", talk.getProperty("durationMin").getLong() + 10);
    talk.setProperty("tags", new String[] { "Sling", "JCR", "Rookie" });

    // save changes to repository (implicit transaction)
    pSession.save();
  }

}
