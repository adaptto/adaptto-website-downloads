//$URL: http://feanor:8050/svn/work/trunk/Intern/Veranstaltungen/130923_adaptTo/presentations_pro!vision/source/rookiedemo/src/main/java/org/adaptto/demo/rookie/components/ResourceSiblingNavigator.java $
//$Id: ResourceSiblingNavigator.java 22795 2013-09-18 20:49:36Z PRO-VISION\SSeifert $
package org.adaptto.demo.rookie.components;

import java.io.IOException;
import java.io.Writer;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;

/**
 * Navigation links for talk "sibling" nodes next talk/previous talk.
 */
@SlingServlet(resourceTypes="/apps/rookiedemo/components/resourceSiblingNavigator")
public class ResourceSiblingNavigator extends SlingSafeMethodsServlet {
  private static final long serialVersionUID = 6609210109107816202L;

  @Override
  protected void doGet(SlingHttpServletRequest pRequest, SlingHttpServletResponse pResponse) throws ServletException, IOException {
    Writer out = pResponse.getWriter();

    // get previous/next sibling
    Resource previousResource = null;
    Resource currentResource = null;
    Resource nextResource = null;
    for (Resource sibling : pRequest.getResource().getParent().getChildren()) {
      if (currentResource!=null) {
        nextResource = sibling;
        break;
      }
      else if (StringUtils.equals(sibling.getPath(), pRequest.getResource().getPath())) {
        currentResource = pRequest.getResource();
      }
      else {
        previousResource = sibling;
      }
    }

    // anchor for previous/next sibling
    if (previousResource!=null) {
      out.write(" | <a href=\"" + previousResource.getPath() + ".html\">Previous</a>");
    }
    if (nextResource!=null) {
      out.write(" | <a href=\"" + nextResource.getPath() + ".html\">Next</a>");
    }

  }

}
