adaptTo() Rookie Demo Sample Project
====================================

Preparations:
- Make sure you have Maven 3 installed
- If running in Sling make sure to use the latest released versions of all bundles
- If running in CQ561 please make sure to install this updated taglib bundle and restart CQ5:
  http://central.maven.org/maven2/org/apache/sling/org.apache.sling.scripting.jsp.taglib/2.2.0/org.apache.sling.scripting.jsp.taglib-2.2.0.jar

Build the project using:
mvn clean install

Deploy the project including sample content to JCR repository (check "Sling instance parameters" in pom.xml before):
mvn sling:install

Go to demo intro page
http://localhost:4502/content/adaptto.html

---

For developing the JSPs with instant feedback in the running instance deploy the Filesystem Resource Provider bundle:
http://central.maven.org/maven2/org/apache/sling/org.apache.sling.fsresource/1.1.2/org.apache.sling.fsresource-1.1.2.jar

And create a new configuration "Apache Sling Filesystem Resource Provider" with
- Provier Root = "/apps/rookiedemo"
- Filesystem Root = <project root>\src\main\webapp\app-root
